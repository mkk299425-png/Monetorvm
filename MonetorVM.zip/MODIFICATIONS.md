# Monetor modifications

Copyright 2026 Monetor for the modifications documented here.

This is a derivative of LuaObfVM, originally developed by OnlyTris. The original Apache License 2.0 and required attribution notices are retained. This file records changes made in this derivative; it does not itself transfer ownership of upstream material.

- Changed the generated output header to `-- تم التشفير بواسطة Monetor`.
- Changed the default embedded watermark to `Hello, Im Monetor`.
- Updated generator decoy assertion messages and minifier decoy strings to Monetor branding.
- Updated README and examples documentation.
- Removed pre-generated example outputs so the repository does not ship stale outputs with the old watermark.
