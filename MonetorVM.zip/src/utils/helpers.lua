-- Helper utilities shared across compiler modules
local helpers = {}

function helpers.bit_range(val, start, len)
    local shifted = math.floor(val / (2 ^ start))
    return shifted % (2 ^ len)
end

function helpers.from_int(x, b)
    b = b or 4
    x = math.floor(x)
    if x < 0 then
        x = 4294967296 + x
    end
    local v = {}
    for i = 1, b do
        local c = x % 256
        table.insert(v, c)
        x = math.floor(x / 256)
    end
    return v
end

function helpers.toEscStr(arr)
    local s = ""
    if #arr > 0 then
        s = s .. "\\"
    end
    return s .. table.concat(arr, "\\")
end

function helpers.toEscStrBytes(bytes)
    local s = ""
    for i = 1, #bytes do
        s = s .. "\\" .. bytes[i]
    end
    return s
end

function helpers.toEscStrF(str)
    local s = ""
    for i = 1, #str do
        s = s .. "\\" .. string.byte(str, i)
    end
    return s
end

local name_counter = 0
local name_chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"
local name_keywords = {
    ["and"] = true, ["break"] = true, ["do"] = true, ["else"] = true,
    ["elseif"] = true, ["end"] = true, ["false"] = true, ["for"] = true,
    ["function"] = true, ["if"] = true, ["in"] = true, ["local"] = true,
    ["nil"] = true, ["not"] = true, ["or"] = true, ["repeat"] = true,
    ["return"] = true, ["then"] = true, ["true"] = true, ["until"] = true,
    ["while"] = true
}

function helpers.resetCounter()
    name_counter = 0
end

local function getShortName(idx)
    local base = #name_chars
    local name = ""
    local temp = idx
    while temp > 0 do
        local rem = (temp - 1) % base
        name = string.sub(name_chars, rem + 1, rem + 1) .. name
        temp = math.floor((temp - 1) / base)
    end
    return name
end

function helpers.genNextName()
    local name
    repeat
        name_counter = name_counter + 1
        name = getShortName(name_counter)
    until not name_keywords[name]
    return name
end

function helpers.genChars(length)
    return helpers.genNextName()
end

function helpers.generateString(length)
    return helpers.genNextName()
end

function helpers.BitXOR(a, b)
    local p, c = 1, 0
    while a > 0 and b > 0 do
        local ra, rb = a % 2, b % 2
        if ra ~= rb then c = c + p end
        a, b, p = math.floor((a - ra) / 2), math.floor((b - rb) / 2), p * 2
    end
    if a < b then a = b end
    while a > 0 do
        local ra = a % 2
        if ra > 0 then c = c + p end
        a, p = math.floor((a - ra) / 2), p * 2
    end
    return c
end

function helpers.xorStrArr(bytes, key)
    local result = {}
    local j = 1
    local length = #bytes
    for i = 1, length do
        local b_code
        if type(bytes) == "string" then
            b_code = string.byte(bytes, i)
        else
            local b_val = bytes[i]
            b_code = type(b_val) == "string" and string.byte(b_val) or b_val
        end
        local k_code = string.byte(key, j)
        table.insert(result, helpers.BitXOR(b_code, k_code))
        j = j + 1
        if j > #key then
            j = 1
        end
    end
    return result
end

function helpers.shuffleArray(tbl)
    local n = #tbl
    for i = n, 2, -1 do
        local j = math.random(1, i)
        tbl[i], tbl[j] = tbl[j], tbl[i]
    end
    return tbl
end

return helpers
