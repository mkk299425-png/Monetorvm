
local minifier = {}

local QuotesSpam = {
    "Monetor",
    "MonetorVM",
    "MonetorLua",
    "monetor.lua"
}

function minifier.minify(source)
    local p = 1
    local len = #source
    local tokens = {}
    
    local function consume(n)
        n = n or 1
        p = p + n
    end
    
    while p <= len do
        local c_byte = string.byte(source, p)
        local c2_byte = string.byte(source, p + 1)
        
        if c_byte == 45 and c2_byte == 45 then -- '--'
            consume(2)
            local is_long = false
            if string.byte(source, p) == 91 then -- '['
                local eq_count = 0
                local look_p = p + 1
                while string.byte(source, look_p) == 61 do -- '='
                    eq_count = eq_count + 1
                    look_p = look_p + 1
                end
                if string.byte(source, look_p) == 91 then -- '['
                    is_long = true
                    consume(eq_count + 2)
                    while p <= len do
                        if string.byte(source, p) == 93 then -- ']'
                            local match = true
                            for i = 1, eq_count do
                                if string.byte(source, p + i) ~= 61 then
                                    match = false
                                    break
                                end
                            end
                            if match and string.byte(source, p + eq_count + 1) == 93 then
                                consume(eq_count + 2)
                                break
                            end
                        end
                        consume()
                    end
                end
            end
            if not is_long then
                while p <= len do
                    local b = string.byte(source, p)
                    if b == 10 or b == 13 then
                        break
                    end
                    consume()
                end
            end
            
        elseif c_byte == 91 and (c2_byte == 91 or c2_byte == 61) then -- '[' and ('[' or '=')
            local start_p = p
            local eq_count = 0
            consume()
            while string.byte(source, p) == 61 do
                eq_count = eq_count + 1
                consume()
            end
            if string.byte(source, p) == 91 then
                consume()
                while p <= len do
                    if string.byte(source, p) == 93 then
                        local match = true
                        for i = 1, eq_count do
                            if string.byte(source, p + i) ~= 61 then
                                match = false
                                break
                            end
                        end
                        if match and string.byte(source, p + eq_count + 1) == 93 then
                            consume(eq_count + 2)
                            break
                        end
                    end
                    consume()
                end
                table.insert(tokens, { type = "string", value = string.sub(source, start_p, p - 1) })
            else
                p = start_p
                consume()
                table.insert(tokens, { type = "symbol", value = "[" })
            end
            
        elseif c_byte == 34 or c_byte == 39 then -- '"' or "'"
            local quote = c_byte
            local start_p = p
            consume()
            while p <= len do
                local b = string.byte(source, p)
                if b == 92 then -- '\'
                    consume(2)
                elseif b == quote then
                    consume()
                    break
                elseif b == 10 or b == 13 then
                    consume()
                else
                    consume()
                end
            end
            table.insert(tokens, { type = "string", value = string.sub(source, start_p, p - 1) })
          
        elseif (c_byte >= 9 and c_byte <= 13) or c_byte == 32 then -- space/tab/newline
            consume()
            while p <= len do
                local b = string.byte(source, p)
                if not (b == 32 or (b >= 9 and b <= 13)) then
                    break
                end
                consume()
            end
            table.insert(tokens, { type = "space", value = " " })
            
        elseif (c_byte >= 48 and c_byte <= 57) or (c_byte == 46 and c2_byte and c2_byte >= 48 and c2_byte <= 57) then
            local start_p = p
            if c_byte == 48 and (c2_byte == 120 or c2_byte == 88) then -- '0x' or '0X'
                consume(2)
                while p <= len do
                    local b = string.byte(source, p)
                    if not ((b >= 48 and b <= 57) or (b >= 65 and b <= 70) or (b >= 97 and b <= 102) or b == 46) then
                        break
                    end
                    consume()
                end
            else
                while p <= len do
                    local b = string.byte(source, p)
                    if not ((b >= 48 and b <= 57) or b == 46 or b == 101 or b == 69 or b == 45 or b == 43) then
                        break
                    end
                    if b == 45 or b == 43 then -- '-' or '+'
                        local prev = string.byte(source, p - 1)
                        if prev ~= 101 and prev ~= 69 then -- 'e' or 'E'
                            break
                        end
                    end
                    consume()
                end
            end
            table.insert(tokens, { type = "number", value = string.sub(source, start_p, p - 1) })
        elseif (c_byte >= 65 and c_byte <= 90) or (c_byte >= 97 and c_byte <= 122) or c_byte == 95 then -- 'A-Z', 'a-z', '_'
            local start_p = p
            consume()
            while p <= len do
                local b = string.byte(source, p)
                if not ((b >= 48 and b <= 57) or (b >= 65 and b <= 90) or (b >= 97 and b <= 122) or b == 95) then
                    break
                end
                consume()
            end
            table.insert(tokens, { type = "word", value = string.sub(source, start_p, p - 1) })
        else
            local start_p = p
            if (c_byte == 61 or c_byte == 126 or c_byte == 60 or c_byte == 62) and c2_byte == 61 then -- '==', '~=', '<=', '>='
                consume(2)
            elseif c_byte == 46 and c2_byte == 46 then -- '..'
                if string.byte(source, p + 2) == 46 then -- '...'
                    consume(3)
                else
                    consume(2)
                end
            else
                consume()
            end
            table.insert(tokens, { type = "symbol", value = string.sub(source, start_p, p - 1) })
        end
    end
    
    for i = 1, #tokens do
        local tok = tokens[i]
        if tok.type == "number" then
            local n = tonumber(tok.value)
            if n and math.random() > 0.9 and not string.find(tok.value, "[%.xXeE]") and n > 0 and n < 40 then
                local quot = QuotesSpam[math.random(1, #QuotesSpam)]
                local diff = #quot - n
                local diff_str = tostring(diff)
                if diff < 0 then
                    diff_str = "- " .. math.abs(diff)
                end
                if math.random() > 0.6 then
                    tok.value = "((function(A) return (#A - " .. diff_str .. ") end)('" .. quot .. "'))"
                else
                    tok.value = "(#('" .. quot .. "') - " .. diff_str .. ")"
                end
            end
        end
    end
    
    local output = {}
    local last_tok = nil
    
    for i = 1, #tokens do
        local tok = tokens[i]
        if tok.type ~= "space" then
            if last_tok then
                local need_space = false
                local l_val = last_tok.value
                local t_val = tok.value
                
                local l_is_w = (last_tok.type == "word" or last_tok.type == "number")
                local t_is_w = (tok.type == "word" or tok.type == "number")
                
                if l_is_w and t_is_w then
                    need_space = true
                elseif string.sub(l_val, -1) == "-" and string.sub(t_val, 1, 1) == "-" then
                    need_space = true
                elseif string.sub(l_val, -1) == "." and string.sub(t_val, 1, 1) == "." then
                    need_space = true
                elseif string.sub(l_val, -1) == "[" and string.sub(t_val, 1, 1) == "[" then
                    need_space = true
                end
                
                if need_space then
                    table.insert(output, " ")
                end
            end
            table.insert(output, tok.value)
            last_tok = tok
        end
    end
    
    return table.concat(output)
end

function minifier.obfuscate_names(source, var_map)
    local p = 1
    local len = #source
    local tokens = {}
    
    local function consume(n)
        n = n or 1
        p = p + n
    end
    
    while p <= len do
        local c_byte = string.byte(source, p)
        local c2_byte = string.byte(source, p + 1)
    
        if c_byte == 45 and c2_byte == 45 then -- '--'
            local start_p = p
            consume(2)
            local is_long = false
            if string.byte(source, p) == 91 then -- '['
                local eq_count = 0
                local look_p = p + 1
                while string.byte(source, look_p) == 61 do -- '='
                    eq_count = eq_count + 1
                    look_p = look_p + 1
                end
                if string.byte(source, look_p) == 91 then -- '['
                    is_long = true
                    consume(eq_count + 2)
                    while p <= len do
                        if string.byte(source, p) == 93 then -- ']'
                            local match = true
                            for i = 1, eq_count do
                                if string.byte(source, p + i) ~= 61 then
                                    match = false
                                    break
                                end
                            end
                            if match and string.byte(source, p + eq_count + 1) == 93 then
                                consume(eq_count + 2)
                                break
                            end
                        end
                        consume()
                    end
                end
            end
            if not is_long then
                while p <= len do
                    local b = string.byte(source, p)
                    if b == 10 or b == 13 then
                        break
                    end
                    consume()
                end
            end
            table.insert(tokens, { type = "comment", value = string.sub(source, start_p, p - 1) })
            
        elseif c_byte == 91 and (c2_byte == 91 or c2_byte == 61) then -- '[' and ('[' or '=')
            local start_p = p
            local eq_count = 0
            consume()
            while string.byte(source, p) == 61 do
                eq_count = eq_count + 1
                consume()
            end
            if string.byte(source, p) == 91 then
                consume()
                while p <= len do
                    if string.byte(source, p) == 93 then
                        local match = true
                        for i = 1, eq_count do
                            if string.byte(source, p + i) ~= 61 then
                                match = false
                                break
                            end
                        end
                        if match and string.byte(source, p + eq_count + 1) == 93 then
                            consume(eq_count + 2)
                            break
                        end
                    end
                    consume()
                end
                table.insert(tokens, { type = "string", value = string.sub(source, start_p, p - 1) })
            else
                p = start_p
                consume()
                table.insert(tokens, { type = "symbol", value = "[" })
            end
            
        elseif c_byte == 34 or c_byte == 39 then -- '"' or "'"
            local quote = c_byte
            local start_p = p
            consume()
            while p <= len do
                local b = string.byte(source, p)
                if b == 92 then -- '\'
                    consume(2)
                elseif b == quote then
                    consume()
                    break
                elseif b == 10 or b == 13 then
                    consume()
                else
                    consume()
                end
            end
            table.insert(tokens, { type = "string", value = string.sub(source, start_p, p - 1) })
            
        elseif (c_byte >= 9 and c_byte <= 13) or c_byte == 32 then
            local start_p = p
            consume()
            while p <= len do
                local b = string.byte(source, p)
                if not (b == 32 or (b >= 9 and b <= 13)) then
                    break
                end
                consume()
            end
            table.insert(tokens, { type = "space", value = string.sub(source, start_p, p - 1) })
            
        elseif (c_byte >= 48 and c_byte <= 57) or (c_byte == 46 and c2_byte and c2_byte >= 48 and c2_byte <= 57) then
            local start_p = p
            if c_byte == 48 and (c2_byte == 120 or c2_byte == 88) then -- '0x' or '0X'
                consume(2)
                while p <= len do
                    local b = string.byte(source, p)
                    if not ((b >= 48 and b <= 57) or (b >= 65 and b <= 70) or (b >= 97 and b <= 102) or b == 46) then
                        break
                    end
                    consume()
                end
            else
                while p <= len do
                    local b = string.byte(source, p)
                    if not ((b >= 48 and b <= 57) or b == 46 or b == 101 or b == 69 or b == 45 or b == 43) then
                        break
                    end
                    if b == 45 or b == 43 then -- '-' or '+'
                        local prev = string.byte(source, p - 1)
                        if prev ~= 101 and prev ~= 69 then -- 'e' or 'E'
                            break
                        end
                    end
                    consume()
                end
            end
            table.insert(tokens, { type = "number", value = string.sub(source, start_p, p - 1) })
            
        elseif (c_byte >= 65 and c_byte <= 90) or (c_byte >= 97 and c_byte <= 122) or c_byte == 95 then -- 'A-Z', 'a-z', '_'
            local start_p = p
            consume()
            while p <= len do
                local b = string.byte(source, p)
                if not ((b >= 48 and b <= 57) or (b >= 65 and b <= 90) or (b >= 97 and b <= 122) or b == 95) then
                    break
                end
                consume()
            end
            table.insert(tokens, { type = "word", value = string.sub(source, start_p, p - 1) })
            
        else
            local start_p = p
            if (c_byte == 61 or c_byte == 126 or c_byte == 60 or c_byte == 62) and c2_byte == 61 then -- '==', '~=', '<=', '>='
                consume(2)
            elseif c_byte == 46 and c2_byte == 46 then -- '..'
                if string.byte(source, p + 2) == 46 then -- '...'
                    consume(3)
                else
                    consume(2)
                end
            else
                consume()
            end
            table.insert(tokens, { type = "symbol", value = string.sub(source, start_p, p - 1) })
        end
    end
    
    local output = {}
    for i = 1, #tokens do
        local tok = tokens[i]
        if tok.type == "word" and var_map[tok.value] then
            table.insert(output, var_map[tok.value])
        else
            table.insert(output, tok.value)
        end
    end
    
    return table.concat(output)
end

return minifier
