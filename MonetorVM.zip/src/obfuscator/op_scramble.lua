-- Opcode
local op_scramble = {}

local helpers = require("src.utils.helpers")

function op_scramble.scrambleOpcodes(opnames)
    local scrambled = {}
    local taken = {}
    for idx = 1, #opnames do
        local a
        repeat
            a = helpers.genNextName()
        until not taken[a]
        taken[a] = idx - 1
        scrambled[idx - 1] = a
    end
    return scrambled, taken
end

return op_scramble
