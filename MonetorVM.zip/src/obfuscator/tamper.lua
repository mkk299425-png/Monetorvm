-- Anti-Tamper
local tamper = {}

local helpers = require("src.utils.helpers")

function tamper.inject_tamper_verification(tree, opmap)
    opmap["VERIFY"] = opmap["VERIFY"] or helpers.genNextName()
    opmap["CHECKLINE"] = opmap["CHECKLINE"] or helpers.genNextName()
    
    local main_instr = tree.Chunk.Instr
    local function make_verify()
        return {
            [1] = 0, [2] = 0, [3] = nil,
            Enum = opmap["VERIFY"], Value = 0, Type = "AsBx", Name = "VERIFY"
        }
    end
    local checkline_inst = {
        [1] = 0, [2] = 0, [3] = nil,
        Enum = opmap["CHECKLINE"], Value = 0, Type = "AsBx", Name = "CHECKLINE"
    }
    table.insert(main_instr, 1, make_verify())
    table.insert(main_instr, 2, checkline_inst)
    local mid = math.max(3, math.floor(#main_instr / 2))
    table.insert(main_instr, mid, make_verify())
    if #main_instr > 5 then
        table.insert(main_instr, #main_instr, make_verify())
    end
end

return tamper
