-- String extraction
local string_extract = {}

local helpers = require("src.utils.helpers")

function string_extract.extract_strings(s, XORSecondary, constTableVar)
    constTableVar = constTableVar or "c"
    local out = {}
    local i = 1
    local len = #s
    local indexes = {}
    local arr = {}
    
    while i <= len do
        local c = string.sub(s, i, i)
        if c == "'" or c == '"' then
            local quote = c
            local start_pos = i
            i = i + 1
            local escaped = false
            while i <= len do
                local sc = string.sub(s, i, i)
                if escaped then
                    escaped = false
                elseif sc == "\\" then
                    escaped = true
                elseif sc == quote then
                    break
                end
                i = i + 1
            end
            
            local full_str = string.sub(s, start_pos, i)
            local content = string.sub(s, start_pos + 1, i - 1)
            
            if string.match(full_str, "^['\"]IGNORE:") then
                table.insert(out, full_str)
            else
                local name = indexes[full_str]
                if not name then
                    name = helpers.genNextName()
                    indexes[full_str] = name
                    
                    local enc_name = helpers.xorStrArr(name, XORSecondary)
                    local enc_content = helpers.xorStrArr(content, XORSecondary)
                    
                    local line = constTableVar .. '[XORStringSec("' .. helpers.toEscStr(enc_name) .. '")] = XORString("' .. helpers.toEscStr(enc_content) .. '", xorSecondaryKey);'
                    table.insert(arr, line)
                end
                table.insert(out, "(" .. constTableVar .. "." .. indexes[full_str] .. ")")
            end
        else
            table.insert(out, c)
        end
        i = i + 1
    end
    
    local final_s = table.concat(out)
    final_s = string.gsub(final_s, "(['\"])IGNORE:", "%1")
    return final_s, arr
end

return string_extract
