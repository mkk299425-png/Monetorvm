-- package
local obfuscator = {}

local control_flow = require("src.obfuscator.control_flow")
local string_extract = require("src.obfuscator.string_extract")
local op_scramble = require("src.obfuscator.op_scramble")
local constants = require("src.obfuscator.constants")
local super_ops = require("src.obfuscator.super_ops")
local tamper = require("src.obfuscator.tamper")

obfuscator.cControlFlow = control_flow.cControlFlow
obfuscator.extract_strings = string_extract.extract_strings
obfuscator.scrambleOpcodes = op_scramble.scrambleOpcodes
obfuscator.inject_dconsts = constants.inject_dconsts
obfuscator.encrypt_constants = constants.encrypt_constants
obfuscator.generate_super_operators = super_ops.generate_super_operators
obfuscator.inject_tamper_verification = tamper.inject_tamper_verification

return obfuscator
