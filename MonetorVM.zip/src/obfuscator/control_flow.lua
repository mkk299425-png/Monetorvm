-- Control flow flattening
local control_flow = {}

function control_flow.cControlFlow(code, n, a, depth, depthValues)
    n = n or math.random(1, 7000)
    a = a or math.random(1, 7000)
    depth = depth or 0
    depthValues = depthValues or {}
    
    local current_depth = depth + 1
    depthValues[current_depth] = {n, a, nil}
    
    local src = (depth == 0) and ("local N_1_ = " .. n .. ";\nlocal A_1_ = " .. a .. ";\n") or ""
    
    if n < a then
        src = src .. "while (N_1_ < A_1_) do;\n"
        src = src .. "A_1_ = N_1_ - " .. (a * 2) .. ";\n"
        a = n - (a * 2)
        depthValues[current_depth][3] = "1"
    elseif n > a then
        local ran = math.random(10, 5010)
        src = src .. "while (N_1_ > (A_1_ - " .. (math.random(0, 2) + 10) .. ")) do;\n"
        src = src .. "A_1_ = (N_1_ + " .. ran .. ") * 2;\n"
        a = (n + ran) * 2
        depthValues[current_depth][3] = "2"
    else
        local ran = math.random(10, 5010)
        src = src .. "while (N_1_ == A_1_) do\n;"
        src = src .. "A_1_ = (N_1_ + " .. ran .. ") * 2;\n;"
        a = (n + ran) * 2
        depthValues[current_depth][3] = "3"
    end
    
    if depth == (#code - 1) then
        src = src .. table.remove(code, 1) .. "\n"
    else
        local res_src, res_n, res_a = control_flow.cControlFlow(code, n, a, depth + 1, depthValues)
        src = src .. res_src
        n = res_n
        a = res_a
    end
    src = src .. "end;\n"
    
    local dp = depthValues[current_depth - 1]
    if dp ~= nil then
        local dn, da, dt = dp[1], dp[2], dp[3]
        if n > a then
            src = src .. "if N_1_ > (A_1_ - " .. (n * 2) .. ") then\n"
        elseif n < a then
            src = src .. "if (" .. (n * 2) .. " - N_1_) < (A_1_ + " .. (n + math.random(0, 49)) .. ") then\n"
        elseif n == a then
            src = src .. "if N_1_ == A_1_ then\n"
        end
        
        if dt == "1" then
            src = src .. "N_1_ = ((A_1_ + " .. dn .. ") * 2);\n"
            n = (a + dn) * 2
            if code[1] ~= nil then
                src = src .. table.remove(code, 1) .. "\n"
            end
            src = src .. "end;\n"
        elseif dt == "2" then
            src = src .. "A_1_ = (N_1_ + " .. (dn * 2) .. ");\n"
            a = n + (dn * 2)
            if code[1] ~= nil then
                src = src .. table.remove(code, 1) .. "\n"
            end
            src = src .. "end;\n"
        elseif dt == "3" then
            src = src .. "N_1_ = (A_1_ / 2) - " .. (tonumber(dt) * 2) .. ";\n"
            n = (a / 2) - (tonumber(dt) * 2)
            if code[1] ~= nil then
                src = src .. table.remove(code, 1) .. "\n"
            end
            src = src .. "end;\n"
        end
    end
    
    if depth == 0 then
        return src
    else
        return src, n, a
    end
end

return control_flow
