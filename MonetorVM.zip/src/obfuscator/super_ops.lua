-- Super Operators
local super_ops = {}

local helpers = require("src.utils.helpers")

function super_ops.generate_super_operators(chunk, opmap)
    local jump_targets = {}
    for idx = 1, #chunk.Instr do
        local inst = chunk.Instr[idx]
        if inst.References then
            for _, ref in ipairs(inst.References) do
                if ref then
                    jump_targets[ref] = true
                end
            end
        end
    end
    
    local ignored_instructions = {}
    local idx = 1
    while idx <= #chunk.Instr do
        local inst = chunk.Instr[idx]
        local opname = inst.Name
        if opname == "CLOSURE" then
            ignored_instructions[inst] = true
            local proto = chunk.Proto[inst[2] + 1]
            if proto and (not proto.UpvalueInfo or #proto.UpvalueInfo == 0) then
                local num_upvals = proto.Upvals or 0
                for u = 1, num_upvals do
                    local next_inst = chunk.Instr[idx + u]
                    if next_inst then
                        ignored_instructions[next_inst] = true
                    end
                end
                idx = idx + num_upvals
            end
        elseif opname == "EQ" or opname == "LT" or opname == "LE" or
               opname == "TEST" or opname == "TESTSET" or opname == "TFORLOOP" or
               opname == "SETLIST" or opname == "LOADBOOL" or opname == "LOADTRUE" or opname == "LOADFALSE" then
            ignored_instructions[inst] = true
        elseif opname == "FORLOOP" or opname == "FORPREP" or opname == "JMP" then
            ignored_instructions[inst] = true
            if inst.References and inst.References[1] then
                ignored_instructions[inst.References[1]] = true
            end
        elseif opname == "DYNAMICJMP" or opname == "DCONSTS" or opname == "VERIFY" or opname == "CHECKLINE" then
            ignored_instructions[inst] = true
        end
        
        if jump_targets[inst] then
            ignored_instructions[inst] = true
        end
        idx = idx + 1
    end
    
    local super_operators = {}
    local process_instr
    process_instr = function(ip)
        local virtual = { InstrPoint = ip - 1, Instructions = {}, Name = "" }
        table.insert(super_operators, virtual)
        
        while ip < #chunk.Instr do
            local inst = chunk.Instr[ip]
            if ignored_instructions[inst] then
                if #virtual.Instructions < 5 then
                    for k, v in ipairs(super_operators) do
                        if v == virtual then
                            table.remove(super_operators, k)
                            break
                        end
                    end
                end
                
                while ip < #chunk.Instr do
                    ip = ip + 1
                    if not ignored_instructions[chunk.Instr[ip]] then
                        break
                    end
                end
                if ip < #chunk.Instr - 1 then
                    process_instr(ip)
                end
                break
            end
            
            table.insert(virtual.Instructions, inst)
            ip = ip + 1
            if ip >= #chunk.Instr then
                break
            end
            if #virtual.Instructions >= 5 then
                process_instr(ip)
                break
            end
        end
    end
    
    if #chunk.Instr > 1 then
        process_instr(1)
    end
    
    for idx = #super_operators, 1, -1 do
        local sop = super_operators[idx]
        local superopName = "SOP_" .. helpers.genNextName()
        sop.Name = superopName
        
        local scrambled_name = helpers.genNextName()
        opmap[superopName] = scrambled_name
        
        local first_inst = sop.Instructions[1]
        local insert_idx = nil
        for j = 1, #chunk.Instr do
            if chunk.Instr[j] == first_inst then
                insert_idx = j
                break
            end
        end
        
        if insert_idx then
            local sop_inst = {
                [1] = 0,
                [2] = 0,
                [3] = nil,
                IsSuperOp = true,
                Enum = scrambled_name,
                Value = 0,
                Type = "SOP",
                Name = superopName,
                Instructions = sop.Instructions
            }
            table.insert(chunk.Instr, insert_idx, sop_inst)
        end
    end
    
    for i = 1, #chunk.Proto do
        super_ops.generate_super_operators(chunk.Proto[i], opmap)
    end
end

return super_ops
