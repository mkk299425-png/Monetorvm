
local constants = {}

local helpers = require("src.utils.helpers")

function constants.inject_dconsts(tree, opmap)
    opmap["DCONSTS"] = opmap["DCONSTS"] or helpers.genNextName()
    local function prepend_dconsts(chunk)
        local dconsts_inst = {
            [1] = 0,
            [2] = 0,
            [3] = nil,
            Enum = opmap["DCONSTS"],
            Value = 0,
            Type = "NOP",
            Name = "DCONSTS"
        }
        table.insert(chunk.Instr, 1, dconsts_inst)
        
        for i = 1, #chunk.Proto do
            prepend_dconsts(chunk.Proto[i])
        end
    end
    prepend_dconsts(tree.Chunk)
end

function constants.encrypt_constants(chunk, key)
    for i = 1, #chunk.Const do
        local cnst = chunk.Const[i]
        if type(cnst) == "string" then
            local encrypted_bytes = helpers.xorStrArr({string.byte(cnst, 1, #cnst)}, key)
            chunk.Const[i] = {
                encrypted = true,
                data = encrypted_bytes
            }
        end
    end
    
    for i = 1, #chunk.Proto do
        constants.encrypt_constants(chunk.Proto[i], key)
    end
end

return constants
