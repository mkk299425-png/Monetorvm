-- Opcode template libraries and registry maps for Lua 5.1, 5.2, and 5.3
local opcodes = {}

opcodes.OPCODES_51 = {
    ["ADD"] = [[;
local Stk = Stack;

local B;
if (|B| >= 256) then
    B = Chunk['|Const|'][|B| - 256];
else
    B = Stk[|B|];
end

local C;
if (|C| >= 256) then
    C = Chunk['|Const|'][|C| - 256];
else
    C = Stk[|C|];
end

Stk[|A|] = B + C;
]],
    ["BAND"] = [[;
local Stk = Stack;
local B = |B|;
local C = |C|;

if (B >= 256) then
    B = Chunk['|Const|'][B - 256]
else
    B = Stk[B]
end

if (C >= 256) then
    C = Chunk['|Const|'][C - 256]
else
    C = Stk[C]
end

local band = _G.__band or bit32 and bit32.band or (loadstring or load)("return function(a, b) return a & b end")();
_G.__band = band;
Stack[|A|] = band(B, C);
]],
    ["BNOT"] = [[;
local Stk = Stack;
local B = Stk[|B|];

local bnot = _G.__bnot or bit32 and bit32.bnot or (loadstring or load)("return function(a) return ~a end")();
_G.__bnot = bnot;
Stack[|A|] = bnot(B);
]],
    ["BOR"] = [[;
local Stk = Stack;
local B = |B|;
local C = |C|;

if (B >= 256) then
    B = Chunk['|Const|'][B - 256]
else
    B = Stk[B]
end

if (C >= 256) then
    C = Chunk['|Const|'][C - 256]
else
    C = Stk[C]
end

local bor = _G.__bor or bit32 and bit32.bor or (loadstring or load)("return function(a, b) return a | b end")();
_G.__bor = bor;
Stack[|A|] = bor(B, C);
]],
    ["BXOR"] = [[;
local Stk = Stack;
local B = |B|;
local C = |C|;

if (B >= 256) then
    B = Chunk['|Const|'][B - 256]
else
    B = Stk[B]
end

if (C >= 256) then
    C = Chunk['|Const|'][C - 256]
else
    C = Stk[C]
end

local bxor = _G.__bxor or bit32 and bit32.bxor or (loadstring or load)("return function(a, b) return a ~ b end")();
_G.__bxor = bxor;
Stack[|A|] = bxor(B, C);
]],
    ["CALL"] = [[;
local A	= |A|;
local B	= |B|;
local C	= |C|;
local Stk	= Stack;
local Args, Results;
local Limit, Edx;

Args	= {};

if (B ~= 1) then
    if (B ~= 0) then
        Limit = A + B - 1;
    else
        Limit = Top;
    end;

    Edx	= 0;

    for Idx = A + 1, Limit do
        Edx = Edx + 1;

        Args[Edx] = Stk[Idx];
    end;

    Limit, Results = _Returns(Stk[A](unpack(Args, 1, Limit - A)));
else
    Limit, Results = _Returns(Stk[A]());
end;

Top = A - 1;

if (C ~= 1) then
    if (C ~= 0) then
        Limit = A + C - 2;
    else
        Limit = Limit + A - 1;
    end;

    Edx	= 0;

    for Idx = A, Limit do
        Edx = Edx + 1;
        Stk[Idx] = Results[Edx];
    end;
end;

]],
    ["CLOSE"] = [[;
local A		= |A|;
local Cls	= {};

for Idx = 1, #Lupvals do
    local List = Lupvals[Idx];

    for Idz = 0, #List do
        local Upv	= List[Idz];
        local Stk	= Upv[1];
        local Pos	= Upv[2];

        if (Stk == Stack) and (Pos >= A) then
            Cls[Pos]	= Stk[Pos];
            Upv[1]		= Cls;
        end;
    end;
end;
]],
    ["CLOSURE"] = [=[
local NewProto	= Chunk['|Proto|'][|B|];
local Stk	= Stack;

local Indexes;
local NewUvals;

if (NewProto["|T_UPVALS|"] ~= 0) then
    NewUvals	= setmetatable({}, {
            ["__index"] = function(_, Key)
                local Val	= Indexes[Key];

                return Val[1][Val[2]];
            end,
            ["__newindex"] = function(_, Key, Value)
                local Val	= Indexes[Key];

                Val[1][Val[2]]	= Value;
            end;
        }
    );
    Indexes		= {};

    for Idx = 1, NewProto['|T_UPVALS|'] do
        local Mvm	= Chunk['|Inst|'][pc];
        pc	= pc + 1; 
        if (Mvm["|Opcode|"] == "|OP_MOVE|") then 
            Indexes[Idx - 1] = { Stk, Mvm[|BIdx|] };
        elseif (Mvm["|Opcode|"] == "|OP_GETUPVAL|") then 
            Indexes[Idx - 1] = { Upvalues, Mvm[|BIdx|] };
        end;
    end;

    Lupvals[#Lupvals + 1]	= Indexes;
end;

local f, _fr = new(0, "|OP_CLOSURE|", NewProto, Env, NewUvals);
f.__init__(0, '|Const|', '|Inst|', '|Proto|', NewProto['|Args|']);
local wrapped;
wrapped = function(...)
    local my_env = getfenv and getfenv(1) or nil;
    if my_env then f.Env = my_env; end;
    return _fr(f, ...);
end;
f.Func = wrapped;
Stk[|A|] = wrapped;

]=],
    ["CONCAT"] = [[;
local Stk	= Stack;
local B		= |B|;
local K 	= Stk[B];

for Idx = B + 1, |C| do
    K = K .. Stk[Idx];
end;

Stack[|A|]	= K;

]],
    ["DIV"] = [[;
local Stk = Stack;

local B;
if (|B| >= 256) then
    B = Chunk['|Const|'][|B| - 256];
else
    B = Stk[|B|];
end

local C;
if (|C| >= 256) then
    C = Chunk['|Const|'][|C| - 256];
else
    C = Stk[|C|];
end

Stk[|A|] = B / C;
]],
    ["EQ"] = [[;
local Stk = Stack;

local B;
if (|B| >= 256) then
    B = Chunk['|Const|'][|B| - 256];
else
    B = Stk[|B|];
end

local C;
if (|C| >= 256) then
    C = Chunk['|Const|'][|C| - 256];
else
    C = Stk[|C|];
end

local a_bool = (|A| == true or |A| == 1);
if (B == C) ~= a_bool then
    pc = pc + 1;
end;
]],
    ["EXTRAARG"] = [[;




]],
    ["FORLOOP"] = [[;
local A		= |A|;
local Stk	= Stack;

local Step	= Stk[A + 2];
local Index	= Stk[A] + Step;

Stk[A]	= Index;

if (Step > 0) then
    if Index <= Stk[A + 1] then
        pc	= pc + |B|;

        Stk[A + 3] = Index;
    end;
else
    if Index >= Stk[A + 1] then
        pc	= pc + |B|;

        Stk[A + 3] = Index;
    end
end
]],
    ["FORPREP"] = [[;
local A		= |A|;
local Stk	= Stack;


Stk[A] = assert(tonumber(Stk[A]), '`for` initial value must be a number');
Stk[A + 1] = assert(tonumber(Stk[A + 1]), '`for` limit must be a number');
Stk[A + 2] = assert(tonumber(Stk[A + 2]), '`for` step must be a number');

Stk[A]	= Stk[A] - Stk[A + 2];

pc	= pc + |B|;
]],
    ["GETGLOBAL"] = [=[
local key = Chunk['|Const|'][|B|];
local value = Env[key];

if getfenv and key == "getfenv" and value == getfenv then
    value = function(target)
        if target == nil or target == 1 then
            return Env;
        end;
        return getfenv(target);
    end;
elseif setfenv and key == "setfenv" and value == setfenv then
    value = function(target, new_env)
        if target == 1 then
            Env = new_env;
            Chunk.Env = new_env;
            if self_f then self_f.Env = new_env; end;
            return self_f and self_f.Func or nil;
        end;
        return setfenv(target, new_env);
    end;
end;

Stack[|A|] = value;
]=],
    ["GETTABLE"] = [[;
local Stk = Stack;

local key;
if (|C| >= 256) then
    key = Chunk['|Const|'][|C| - 256];
else
    key = Stk[|C|];
end

local tbl = Stk[|B|];
local val;
if tbl ~= nil then
    val = tbl[key];
end;
Stk[|A|] = val;

]],
    ["GETTABUP"] = [[;
local Stk = Stack;

local upval;
if (|B| == 0) then
    upval = Upvalues and Upvalues[0];
    if upval == nil then
        upval = Env;
    end
else
    upval = Upvalues and Upvalues[|B|];
end

local key;
local constIdx;
if (|C| >= 256) then
    constIdx = |C| - 256;
    key = Chunk['|Const|'][constIdx];
else
    key = Stk[|C|];
end

local val = upval and upval[key];
Stk[|A|] = val;
]],
    ["GETUPVAL"] = [[;
local val = Upvalues[|B|];
Stack[|A|] = val;

]],
    ["IDIV"] = [[;

local Stk = Stack;
local B = |B|;
local C = |C|;

if (B >= 256) then
    B = Chunk['|Const|'][B - 256]
else
    B = Stk[B]
end

if (C >= 256) then
    C = Chunk['|Const|'][C - 256]
else
    C = Stk[C]
end

Stack[|A|] = math.floor(B / C);

]],
    ["JMP"] = [[;
local sBx = |B|;
local A = |A|;
if A and A > 0 then
    local close_index = A - 1;
    local Cls = {};
    for Idx = 1, #Lupvals do
        local List = Lupvals[Idx];
        for Idz = 0, #List do
            local Upv = List[Idz];
            local Stk = Upv[1];
            local Pos = Upv[2];
            if (Stk == Stack) and (Pos >= close_index) then
                Cls[Pos] = Stk[Pos];
                Upv[1] = Cls;
            end;
        end;
    end;
end;
pc = pc + sBx;
]],
    ["LE"] = [[;
local Stk = Stack;

local B;
if (|B| >= 256) then
    B = Chunk['|Const|'][|B| - 256];
else
    B = Stk[|B|];
end

local C;
if (|C| >= 256) then
    C = Chunk['|Const|'][|C| - 256];
else
    C = Stk[|C|];
end

local a_bool = (|A| == true or |A| == 1);
if (B <= C) ~= a_bool then
    pc = pc + 1;
end;
]],
    ["LEN"] = [[;
Stack[|A|]	= #Stack[|B|];
]],
    ["LOADBOOL"] = [[;
Stack[|A|]	= (|B| ~= 0);

if (|C| ~= 0) then
    pc	= pc + 1;
end;
]],
    ["LOADK"] = [[;

Stack[|A|] = Chunk['|Const|'][|B|]
]],
    ["LOADKX"] = [=[


local nextInst = Chunk['|Inst|'][pc];
pc = pc + 1;
Stack[|A|] = Chunk['|Const|'][nextInst[2] or nextInst[1]];

]=],
    ["LOADNIL"] = [[;
local Stk	= Stack;

for Idx = |A|, |B| do
    Stk[Idx]	= nil;
end;
]],
    ["LT"] = [[;
local Stk = Stack;

local B;
if (|B| >= 256) then
    B = Chunk['|Const|'][|B| - 256];
else
    B = Stk[|B|];
end

local C;
if (|C| >= 256) then
    C = Chunk['|Const|'][|C| - 256];
else
    C = Stk[|C|];
end

local a_bool = (|A| == true or |A| == 1);
if (B < C) ~= a_bool then
    pc = pc + 1;
end;
]],
    ["MOD"] = [[;
local Stk = Stack;

local B;
if (|B| >= 256) then
    B = Chunk['|Const|'][|B| - 256];
else
    B = Stk[|B|];
end

local C;
if (|C| >= 256) then
    C = Chunk['|Const|'][|C| - 256];
else
    C = Stk[|C|];
end

Stk[|A|] = B % C;
]],
    ["MOVE"] = [[;
local val = Stack[|B|];
Stack[|A|] = val;

]],
    ["MUL"] = [[;
local Stk = Stack;

local B;
if (|B| >= 256) then
    B = Chunk['|Const|'][|B| - 256];
else
    B = Stk[|B|];
end

local C;
if (|C| >= 256) then
    C = Chunk['|Const|'][|C| - 256];
else
    C = Stk[|C|];
end

Stk[|A|] = B * C;
]],
    ["NEWTABLE"] = [[;
Stack[|A|]	= {};
]],
    ["NOT"] = [[;
Stack[|A|]	= (not Stack[|B|]);
]],
    ["POW"] = [[;
local Stk = Stack;

local B;
if (|B| >= 256) then
    B = Chunk['|Const|'][|B| - 256];
else
    B = Stk[|B|];
end

local C;
if (|C| >= 256) then
    C = Chunk['|Const|'][|C| - 256];
else
    C = Stk[|C|];
end

Stk[|A|] = B ^ C;
]],
    ["RETURN"] = [[;
local A	= |A|;
local B	= |B|;
local Stk = Stack;
local Edx, Output;
local Limit;

if (B == 1) then
    return;
elseif (B == 0) then
    Limit	= Top;
else
    Limit	= A + B - 2;
end;

Output = {};
Edx = 0;

for Idx = A, Limit do
    Edx	= Edx + 1;
    Output[Edx] = Stk[Idx];
end;
do
    return Output, Edx;
end
]],
    ["SELF"] = [[;
local Stk = Stack;
local A = |A|;
local B = Stk[|B|];

local key;
if (|C| >= 256) then
    key = Chunk['|Const|'][|C| - 256];
else
    key = Stk[|C|];
end

local method = B and B[key] or nil;
Stk[A + 1] = B;
Stk[A] = method;

]],
    ["SETGLOBAL"] = [=[
Env[Chunk['|Const|'][|B|]]	= Stack[|A|];
]=],
    ["SETLIST"] = [[;
local A		= |A|;
local B		= |B|;
local C		= |C|;
local Stk	= Stack;

if (C == 0) then
    pc	= pc + 1;
    local nextInst = Chunk['|Inst|'][pc];
    C			= nextInst[2] or nextInst[1] or nextInst[4];
end;

local Offset	= (C - 1) * 50;
local T			= Stk[A]; 

if (B == 0) then
    B	= Top - A;
end;

for Idx = 1, B do
    T[Offset + Idx] = Stk[A + Idx];
end;
]],
    ["SETTABLE"] = [[;
local Stk = Stack;

local key;
if (|B| >= 256) then
    key = Chunk['|Const|'][|B| - 256];
else
    key = Stk[|B|];
end

local value;
if (|C| >= 256) then
    value = Chunk['|Const|'][|C| - 256];
else
    value = Stk[|C|];
end

Stk[|A|][key] = value;
]],
    ["SETTABUP"] = [[;
local Stk = Stack;

local upval;
if (|A| == 0) then
    upval = Upvalues and Upvalues[0];
    if upval == nil then
        upval = Env;
    end
else
    upval = Upvalues and Upvalues[|A|];
end

local key;
if (|B| >= 256) then
    key = Chunk['|Const|'][|B| - 256];
else
    key = Stk[|B|];
end

local value;
if (|C| >= 256) then
    value = Chunk['|Const|'][|C| - 256];
else
    value = Stk[|C|];
end

if upval then
    upval[key] = value;
end;
]],
    ["SETUPVAL"] = [[;
Upvalues[|B|]	= Stack[|A|];
]],
    ["SHL"] = [[;
local Stk = Stack;
local B = |B|;
local C = |C|;

if (B >= 256) then
    B = Chunk['|Const|'][B - 256]
else
    B = Stk[B]
end

if (C >= 256) then
    C = Chunk['|Const|'][C - 256]
else
    C = Stk[C]
end

local lshift = _G.__lshift or bit32 and bit32.lshift or (loadstring or load)("return function(a, b) return a << b end")();
_G.__lshift = lshift;
Stack[|A|] = lshift(B, C);
]],
    ["SHR"] = [[;
local Stk = Stack;
local B = |B|;
local C = |C|;

if (B >= 256) then
    B = Chunk['|Const|'][B - 256]
else
    B = Stk[B]
end

if (C >= 256) then
    C = Chunk['|Const|'][C - 256]
else
    C = Stk[C]
end

local rshift = _G.__rshift or bit32 and bit32.rshift or (loadstring or load)("return function(a, b) return a >> b end")();
_G.__rshift = rshift;
Stack[|A|] = rshift(B, C);
]],
    ["SUB"] = [[;
local Stk = Stack;

local B;
if (|B| >= 256) then
    B = Chunk['|Const|'][|B| - 256];
else
    B = Stk[|B|];
end

local C;
if (|C| >= 256) then
    C = Chunk['|Const|'][|C| - 256];
else
    C = Stk[|C|];
end

Stk[|A|] = B - C;
]],
    ["TAILCALL"] = [[;
local A	= |A|;
local B	= |B|;
local Stk	= Stack;
local Args, Results;
local Limit;
local Rets = 0;

Args = {};

if (B ~= 1) then
    if (B ~= 0) then
        Limit = A + B - 1;
    else
        Limit = Top;
    end

    for Idx = A + 1, Limit do
        Args[#Args + 1] = Stk[Idx];
    end

    Rets, Results = _Returns(Stk[A](unpack(Args, 1, Limit - A)));
else
    Rets, Results = _Returns(Stk[A]());
end;

do
    return Results, Rets;
end

]],
    ["TEST"] = [[;
local c_bool = (|C| == true or |C| == 1);
local a_bool = not not Stack[|A|];
if a_bool ~= c_bool then
    pc = pc + 1;
end;
]],
    ["TESTSET"] = [[;
local c_bool = (|C| == true or |C| == 1);
local b_val = Stack[|B|];
local b_bool = not not b_val;
if b_bool ~= c_bool then
    pc = pc + 1;
else
    Stack[|A|] = b_val;
end;
]],
    ["TFORCALL"] = [[;


local Stk = Stack;
local A = |A|;
local C = |C|;

local Results = {Stk[A](Stk[A + 1], Stk[A + 2])};


local numResults = C == 0 and #Results or C;
for Idx = 1, numResults do
    Stk[A + 2 + Idx] = Results[Idx];
end;

]],
    ["TFORLOOP"] = [[;
local A		= |A|;
local C		= |C|;
local Stk	= Stack;

local Offset	= A + 2;
local Result	= {Stk[A](Stk[A + 1], Stk[A + 2])};

for Idx = 1, C do
    Stack[Offset + Idx] = Result[Idx];
end;

if (Stk[A + 3] ~= nil) then
    Stk[A + 2]	= Stk[A + 3];
else
    pc	= pc + 1;
end;
]],
    ["UNM"] = [[;
Stack[|A|] = -Stack[|B|]
]],
    ["VARARG"] = [[;
local A	= |A|;
local B	= |B|;
local Stk, Vars	= Stack, Vararg;

Top = A - 1;

for Idx = A, A + (B > 0 and B - 1 or Varargsz) do
    Stk[Idx]	= Vars[Idx - A];
end;
]],
    ["DCONSTS"] = [[;
-- Decoy NOP
]],
    ["VERIFY"] = [=[
if signature ~= "|Signature|" then
    while true do end
end
if not Chunk['|VERIFY_FLAG|'] then
Chunk['|VERIFY_FLAG|'] = true
end
]=],
    ["CHECKLINE"] = [[;local _, str = pcall(function() local a = 1 - "abcdefg" ^ 2 return "waa" / a; end) str = tostring(str or "") local Matched = string.gmatch(str, ':(%d+):')() or string.gmatch(str, ':(%d+)')() or string.gmatch(str, '(%d+)')() local thisLine = tonumber(Matched) local wLine = whatLineErr(pcall(function() local a = "b" ^ 2 return "ooa" % a; end)) if thisLine == nil or wLine == nil or StartLine == nil or (StartLine == thisLine and (wLine ~= StartLine or wLine ~= thisLine)) or (StartLine ~= thisLine and wLine ~= thisLine) then while true do end end]]
}

opcodes.OPCODES_53 = {
    ["CLOSURE"] = [=[

local NewProto	= Chunk['|Proto|'][|B|];
local Stk	= Stack;

local Indexes;
local NewUvals;

if (NewProto["|T_UPVALS|"] ~= 0) then
    NewUvals	= setmetatable({}, {
            ["__index"] = function(_, Key)
                local Val	= Indexes[Key];
                if Val == nil then
                    return nil;
                end
                return Val[1][Val[2]];
            end,
            ["__newindex"] = function(_, Key, Value)
                local Val	= Indexes[Key];
                Val[1][Val[2]]	= Value;
            end;
        }
    );
    Indexes		= {};

    
    local UpvalInfo = NewProto["|UpvalInfo|"];
    for Idx = 1, NewProto['|T_UPVALS|'] do
        local Info = UpvalInfo[Idx];
        local InStack = Info[1];
        local UpIdx = Info[2];

        if (InStack == 1) then
            
            Indexes[Idx - 1] = { Stk, UpIdx };
        else
            
            Indexes[Idx - 1] = { Upvalues, UpIdx };
        end;
    end;

    Lupvals[#Lupvals + 1]	= Indexes;
end;

local f, _fr = new(0, "|OP_CLOSURE|", NewProto, Env, NewUvals);
f.__init__(0, '|Const|', '|Inst|', '|Proto|', NewProto['|Args|']);
local wrapped;
wrapped = function(...)
    local my_env = getfenv and getfenv(1) or nil;
    if my_env then f.Env = my_env; end;
    return _fr(f, ...);
end;
f.Func = wrapped;
Stk[|A|] = wrapped;

]=],
    ["LOADNIL"] = [[;


local Stk = Stack;

for Idx = |A|, |A| + |B| do
    Stk[Idx] = nil;
end;

]],
    ["TFORLOOP"] = [[;



local A = |A|;
local Stk = Stack;

if (Stk[A + 1] ~= nil) then
    Stk[A] = Stk[A + 1];
    pc = pc + |B|;
end;

]],
    ["DCONSTS"] = [[;
-- Decoy NOP
]],
    ["VERIFY"] = [=[
if signature ~= "|Signature|" then
    while true do end
end
if not Chunk['|VERIFY_FLAG|'] then
Chunk['|VERIFY_FLAG|'] = true
end
]=],
    ["CHECKLINE"] = [[;local _, str = pcall(function() local a = 1 - "abcdefg" ^ 2 return "waa" / a; end) str = tostring(str or "") local Matched = string.gmatch(str, ':(%d+):')() or string.gmatch(str, ':(%d+)')() or string.gmatch(str, '(%d+)')() local thisLine = tonumber(Matched) local wLine = whatLineErr(pcall(function() local a = "b" ^ 2 return "ooa" % a; end)) if thisLine == nil or wLine == nil or StartLine == nil or (StartLine == thisLine and (wLine ~= StartLine or wLine ~= thisLine)) or (StartLine ~= thisLine and wLine ~= thisLine) then while true do end end]]
}

opcodes.opdata_51 = {
    Opnames = {
        "MOVE", "LOADK", "LOADBOOL", "LOADNIL",
        "GETUPVAL", "GETGLOBAL", "GETTABLE",
        "SETGLOBAL", "SETUPVAL", "SETTABLE",
        "NEWTABLE", "SELF",
        "ADD", "SUB", "MUL", "DIV",
        "MOD", "POW", "UNM", "NOT",
        "LEN", "CONCAT", "JMP",
        "EQ", "LT", "LE", "TEST",
        "TESTSET", "CALL", "TAILCALL",
        "RETURN", "FORLOOP", "FORPREP",
        "TFORLOOP", "SETLIST", "CLOSE",
        "CLOSURE", "VARARG"
    },
    Opcode = {
        [0] = "ABC", "ABx", "ABC", "ABC",
        "ABC", "ABx", "ABC", "ABx",
        "ABC", "ABC", "ABC", "ABC",
        "ABC", "ABC", "ABC", "ABC",
        "ABC", "ABC", "ABC", "ABC",
        "ABC", "ABC", "AsBx", "ABC",
        "ABC", "ABC", "ABC", "ABC",
        "ABC", "ABC", "ABC", "AsBx",
        "AsBx", "ABC", "ABC", "ABC",
        "ABx", "ABC"
    }
}

opcodes.opdata_53 = {
    Opnames = {
        "MOVE", "LOADK", "LOADKX", "LOADBOOL",
        "LOADNIL", "GETUPVAL", "GETTABUP", "GETTABLE",
        "SETTABUP", "SETUPVAL", "SETTABLE", "NEWTABLE",
        "SELF", "ADD", "SUB", "MUL",
        "MOD", "POW", "DIV", "IDIV",
        "BAND", "BOR", "BXOR", "SHL",
        "SHR", "UNM", "BNOT", "NOT",
        "LEN", "CONCAT", "JMP", "EQ",
        "LT", "LE", "TEST", "TESTSET",
        "CALL", "TAILCALL", "RETURN", "FORLOOP",
        "FORPREP", "TFORCALL", "TFORLOOP", "SETLIST",
        "CLOSURE", "VARARG", "EXTRAARG"
    },
    Opcode = {
        [0] = "ABC",  "ABx",  "ABx",  "ABC",
        "ABC",  "ABC",  "ABC",  "ABC",
        "ABC",  "ABC",  "ABC",  "ABC",
        "ABC",  "ABC",  "ABC",  "ABC",
        "ABC",  "ABC",  "ABC",  "ABC",
        "ABC",  "ABC",  "ABC",  "ABC",
        "ABC",  "ABC",  "ABC",  "ABC",
        "ABC",  "ABC",  "AsBx", "ABC",
        "ABC",  "ABC",  "ABC",  "ABC",
        "ABC",  "ABC",  "ABC",  "AsBx",
        "AsBx", "ABC",  "AsBx", "ABC",
        "ABx",  "ABC",  "Ax"
    }
}

opcodes.opdata_52 = {
    Opnames = {
        "MOVE", "LOADK", "LOADKX", "LOADBOOL", "LOADNIL",
        "GETUPVAL", "GETTABUP", "GETTABLE", "SETTABUP", "SETUPVAL",
        "SETTABLE", "NEWTABLE", "SELF", "ADD", "SUB", "MUL",
        "DIV", "MOD", "POW", "UNM", "NOT", "LEN",
        "CONCAT", "JMP", "EQ", "LT", "LE", "TEST",
        "TESTSET", "CALL", "TAILCALL", "RETURN", "FORLOOP", "FORPREP",
        "TFORCALL", "TFORLOOP", "SETLIST", "CLOSURE", "VARARG", "EXTRAARG",
        "IDIV", "BAND", "BNOT", "BOR", "BXOR", "SHL", "SHR"
    },
    Opcode = {
        [0] = "ABC", "ABx", "ABx", "ABC", "ABC",
        "ABC", "ABC", "ABC", "ABC", "ABC",
        "ABC", "ABC", "ABC", "ABC", "ABC", "ABC",
        "ABC", "ABC", "ABC", "ABC", "ABC", "ABC",
        "ABC", "AsBx", "ABC", "ABC", "ABC", "ABC",
        "ABC", "ABC", "ABC", "ABC", "AsBx", "AsBx",
        "ABC", "AsBx", "ABC", "ABx", "ABC", "Ax",
        "ABC", "ABC", "ABC", "ABC", "ABC", "ABC", "ABC"
    }
}

return opcodes
