-- Code generator/VM code assembler
local generator_module = {}

local opcodes = require("src.generator.opcodes")
local obfuscator = require("src.obfuscator.init")
local minifier = require("src.minifier.minifier")
local helpers = require("src.utils.helpers")

local OPCODES_51 = opcodes.OPCODES_51
local OPCODES_53 = opcodes.OPCODES_53
local opdata_51 = opcodes.opdata_51
local opdata_52 = opcodes.opdata_52
local opdata_53 = opcodes.opdata_53

local cControlFlow = obfuscator.cControlFlow
local extract_strings = obfuscator.extract_strings
local scrambleOpcodes = obfuscator.scrambleOpcodes
local inject_dconsts = obfuscator.inject_dconsts
local inject_tamper_verification = obfuscator.inject_tamper_verification
local generate_super_operators = obfuscator.generate_super_operators
local encrypt_constants = obfuscator.encrypt_constants

local minify = minifier.minify

local genChars = helpers.genChars
local generateString = helpers.generateString
local xorStrArr = helpers.xorStrArr
local toEscStr = helpers.toEscStr
local toEscStrBytes = helpers.toEscStrBytes
local toEscStrF = helpers.toEscStrF
local shuffleArray = helpers.shuffleArray
local from_int = helpers.from_int

local function encode_arg(val, bytes_len)
    if val == nil then
        return string.char(0)
    elseif val == false then
        return string.char(1)
    elseif val == true then
        return string.char(2)
    else
        local s = string.char(3)
        if val < 0 then
            val = 4294967296 + val
        end
        for i = 1, bytes_len do
            s = s .. string.char(val % 256)
            val = math.floor(val / 256)
        end
        return s
    end
end

local function CreateInstDecoder(chunk, scrambled_lookup, op_key_seed)
    local eTypes = {
        ABC = 1,
        ABx = 2,
        AsBx = 3,
        Ax = 4,
        SOP = 5,
        NOP = 6
    }
    
    local s = ""
    for idx = 1, #chunk.Instr do
        local inst = chunk.Instr[idx]
        
        local opname = inst.Name
        if opname == "JMP" or opname == "FORLOOP" or opname == "LOADJUMP" or opname == "FORPREP" or opname == "TFORLOOP" then
            if inst.References and inst.References[1] then
                local ref_idx = 1
                for j = 1, #chunk.Instr do
                    if chunk.Instr[j] == inst.References[1] then
                        ref_idx = j
                        break
                    end
                end
                inst[2] = ref_idx - idx - 1
            end
        end

        local op_idx = scrambled_lookup[inst.Enum]
        if not op_idx then
            error("Opcode not found in scrambled list: " .. tostring(inst.Enum))
        end
        
        local inst_key = helpers.BitXOR(idx % 256, op_key_seed)
        local encoded_op_idx = helpers.BitXOR(op_idx, inst_key)
        
        s = s .. string.char(encoded_op_idx % 256)
        s = s .. string.char(math.floor(encoded_op_idx / 256))
        local inst_type = eTypes[inst.Type]
        s = s .. string.char(inst_type)
        
        if inst.Type == "SOP" or inst.Type == "NOP" then
            s = s .. encode_arg(inst.Value, 5)
        elseif inst.Type == "Ax" then
            local ax = inst.Ax or 0
            s = s .. encode_arg(ax, 4)
            s = s .. encode_arg(inst.Value, 5)
        else
            s = s .. encode_arg(inst[1], 1)
            
            local b_val = inst[2] or 0
            if inst.Type == "AsBx" then
                b_val = b_val + 131071
            end
            s = s .. encode_arg(b_val, inst.Type == "ABC" and 2 or 4)
            
            if inst.Type == "ABC" then
                s = s .. encode_arg(inst[3], 2)
            end
            
            s = s .. encode_arg(inst.Value, 5)
        end
    end
    return s
end

local function collect_used_opcodes_with_sops(chunk, set, sops)
    set = set or {}
    sops = sops or {}
    for opname, _ in pairs(chunk.UsedInstructions) do
        set[opname] = true
    end
    for idx = 1, #chunk.Instr do
        local inst = chunk.Instr[idx]
        if inst.IsSuperOp then
            set[inst.Name] = true
            sops[inst.Name] = inst
        elseif inst.Name == "VERIFY" or inst.Name == "CHECKLINE" or inst.Name == "DCONSTS" then
            set[inst.Name] = true
        end
    end
    for idx = 1, #chunk.Proto do
        collect_used_opcodes_with_sops(chunk.Proto[idx], set, sops)
    end
    return set, sops
end

function generator_module.generate_code(tree, settings)
    settings = settings or {}
    if settings.debug == nil then settings.debug = false end
    if settings.anti_tamper == nil then settings.anti_tamper = true end
    if settings.super_operators == nil then settings.super_operators = true end
    if settings.encrypt_constants == nil then settings.encrypt_constants = true end
    if settings.minify == nil then settings.minify = true end

    math.randomseed(os.time())
    helpers.resetCounter()
    
    local function plain_gsub(s, pattern, repl)
        local escaped_repl = string.gsub(tostring(repl), "%%", "%%%%")
        local escaped_pattern = string.gsub(pattern, "([%^%$%(%)%%%.%[%]%*%+%-%?])", "%%%1")
        return string.gsub(s, escaped_pattern, escaped_repl)
    end

    local function remove_empty_separators(code)
        code = string.gsub(code, "^([ \t]*);+", "%1")
        code = string.gsub(code, "(\n[ \t]*);+", "%1")
        for _, keyword in ipairs({"do", "then", "else", "repeat"}) do
            code = string.gsub(code, "(%f[%a]" .. keyword .. "%f[%A][ \t]*);+", "%1")
        end
        return code
    end

    local function serialize_number(value)
        if value ~= value then
            return "(0/0)"
        elseif value == math.huge then
            return "(1/0)"
        elseif value == -math.huge then
            return "(-1/0)"
        elseif value == 0 and (1 / value) == -math.huge then
            return "(-1/(1/0))"
        end
        return tostring(value)
    end

    local XORDecodeCKey = genChars(12)
    local signature = "LuaVM_" .. genChars(8)

    local vm_vars_keys = {
        "new", "signature", "size_constinst", "chunk_or_upvals", "env", "uvals",
        "OpcodeList", "op_key_seed", "Chunk", "current", "ran", "InstLen", "ConstLen",
        "ProtoLen", "isClosure", "Upvalues", "Lupvals", "make_secure_consts", "tbl",
        "backing", "k", "v", "decode_arg", "decode_inst", "decodeLoadStr_to_table",
        "Metamethods", "Run", "self_f", "Env", "pc", "Top", "GStack", "Stack", "Vararg",
        "Varargsz", "ArgCount", "Args", "Idx", "Loop", "ChunkConst", "raw_inst", "Inst", "enum",
        "Result1", "Result2", "VM", "Wrapper", "decodeLoadStr", "_INST", "whatLineErr",
        "StartLine", "_Returns", "fix", "whatfix", "const", "constL", "constCount",
        "inst", "inst_bin", "proto", "protoL", "xorSecondaryKey", "XORStringPrim",
        "XORStringSec", "xorPrimaryKey", "xorDecodeckey", "XORStringPrim1", "XORTableSec",
        "xorStr", "charactertable", "basedictdecompress", "constMTableIndex", "domath",
        "wordindex", "getAWord", "getQWord", "getCWord", "getBWord", "getDWord", "check",
        "reverser", "chartbl", "BitXOR", "XORString", "XORTable", "XORString1Fake",
        "XORTable1Fake", "NumberTable", "TrackNumberTable", "characters", "environment"
    }
    
    local vm_vars = {}
    for idx, key in ipairs(vm_vars_keys) do
        vm_vars[key] = helpers.genNextName()
    end
    
    local anti_names = {}
    if settings.anti_tamper and not settings.debug then
        anti_names = {
            verify_flag = helpers.genNextName(),
        }
    end
    
    local custom_opnames = {}
    if settings.encrypt_constants then
        table.insert(custom_opnames, "DCONSTS")
    end
    if settings.anti_tamper and not settings.debug then
        table.insert(custom_opnames, "VERIFY")
        table.insert(custom_opnames, "CHECKLINE")
    end
    table.insert(custom_opnames, "SUPER_OP")

    local opnames = {}
    local standard_opnames = (tree.LuaVersion == "5.3" or tree.LuaVersion == "5.2") and opdata_53.Opnames or opdata_51.Opnames
    for _, name in ipairs(standard_opnames) do
        table.insert(opnames, name)
    end
    for _, name in ipairs(custom_opnames) do
        table.insert(opnames, name)
    end
    
    local scrambled, taken = scrambleOpcodes(opnames)
    local opmap = {}
    local ropmap = {}
    for idx = 0, #opnames - 1 do
        local original = opnames[idx + 1]
        local scr = scrambled[idx]
        opmap[original] = scr
        ropmap[scr] = original
    end
    
    local op_key_seed = math.random(1, 255)
    
    if settings.anti_tamper and not settings.debug then
        inject_tamper_verification(tree, opmap)
    end
    if settings.encrypt_constants then
        inject_dconsts(tree, opmap)
        encrypt_constants(tree.Chunk, XORDecodeCKey)
    end
    if settings.super_operators then
        generate_super_operators(tree.Chunk, opmap)
    end
    
    local function recalculate_all_jmp_offsets(chunk)
        for idx = 1, #chunk.Instr do
            local inst = chunk.Instr[idx]
            local opname = inst.Name
            if opname == "JMP" or opname == "FORLOOP" or opname == "LOADJUMP" or opname == "FORPREP" or opname == "TFORLOOP" then
                if inst.References and inst.References[1] then
                    local ref_idx = nil
                    for j = 1, #chunk.Instr do
                        if chunk.Instr[j] == inst.References[1] then
                            ref_idx = j
                            break
                        end
                    end
                    if ref_idx then
                        inst[2] = ref_idx - idx - 1
                    end
                end
            end
        end
        for idx = 1, #chunk.Proto do
            recalculate_all_jmp_offsets(chunk.Proto[idx])
        end
    end
    recalculate_all_jmp_offsets(tree.Chunk)
    
    local function scramble_chunk_instr(chunk)
        for idx = 1, #chunk.Instr do
            local inst = chunk.Instr[idx]
            local original_opname = inst.Name
            if opmap[original_opname] then
                inst.Enum = opmap[original_opname]
            end
        end
        for idx = 1, #chunk.Proto do
            scramble_chunk_instr(chunk.Proto[idx])
        end
    end
    scramble_chunk_instr(tree.Chunk)
    
    local scrambled_lookup = {}
    local opcode_list_elements = {}
    local op_list_idx = 1
    for original_name, scr_name in pairs(opmap) do
        scrambled_lookup[scr_name] = op_list_idx
        table.insert(opcode_list_elements, "[" .. op_list_idx .. "] = \"" .. scr_name .. "\"")
        op_list_idx = op_list_idx + 1
    end
    
    local used_ops, sops = collect_used_opcodes_with_sops(tree.Chunk)
    local opcodes_dict = (tree.LuaVersion == "5.3" or tree.LuaVersion == "5.2") and OPCODES_53 or OPCODES_51
    
    local opcodeLadder = ""
    local isFirst = true
    for opname, _ in pairs(used_ops) do
        local code
        if sops[opname] then
            local sop_inst = sops[opname]
            local obf = ""
            for _, v in ipairs(sop_inst.Instructions) do
                local orig_name = ropmap[v.Enum]
                local op_code = opcodes_dict[orig_name] or OPCODES_51[orig_name]
                if op_code then
                    obf = obf .. "\nInst = Chunk['|Inst|'][pc]; pc = pc + 1;\ndo\n" .. op_code .. "\nend\n"
                end
            end
            code = obf
        else
            code = opcodes_dict[opname] or OPCODES_51[opname]
        end
        
        if code then
            local scrambled_name = opmap[opname]
            if isFirst then
                opcodeLadder = opcodeLadder .. "                    if enum == \"" .. scrambled_name .. "\" then\n"
                isFirst = false
            else
                opcodeLadder = opcodeLadder .. "                    elseif enum == \"" .. scrambled_name .. "\" then\n"
            end
            opcodeLadder = opcodeLadder .. "                        " .. string.gsub(code, "\n", "\n                        ") .. "\n"
        end
    end
    if not isFirst then
        opcodeLadder = opcodeLadder .. "                    end\n"
    end
    
    -- Table-based instruction formatter (anti-SSTool)
    local function formatInstAsTable(inst, idx)
        local op_idx = scrambled_lookup[inst.Enum]
        if not op_idx then
            error("Opcode not found in scrambled list: " .. tostring(inst.Enum))
        end
        local inst_key = helpers.BitXOR(idx % 256, op_key_seed)
        local encoded_op = helpers.BitXOR(op_idx, inst_key)
        
        local parts = { "{ [0] = \"" .. tostring(encoded_op) .. "\"" }
        
        if inst[1] ~= nil then
            if type(inst[1]) == "boolean" then
                table.insert(parts, inst[1] and "true" or "false")
            else
                table.insert(parts, tostring(inst[1]))
            end
        else
            table.insert(parts, "nil")
        end
        
        if inst[2] ~= nil then
            if type(inst[2]) == "boolean" then
                table.insert(parts, inst[2] and "true" or "false")
            else
                table.insert(parts, tostring(inst[2]))
            end
        else
            table.insert(parts, "nil")
        end
        
        if inst[3] ~= nil then
            if type(inst[3]) == "boolean" then
                table.insert(parts, inst[3] and "true" or "false")
            else
                table.insert(parts, tostring(inst[3]))
            end
        end
        
        local val = inst.Value or 0
        table.insert(parts, "[4] = " .. tostring(val))
        
        return table.concat(parts, ", ") .. " }"
    end
    
    -- Build main chunk instruction binary string (secure loader style)
    local mainInstStr = CreateInstDecoder(tree.Chunk, scrambled_lookup, op_key_seed)
    local mainInstTableSrc = "    decodeLoadStr('IGNORE:" .. toEscStrF(mainInstStr) .. "')"
    
    -- Format constants loading
    local cnstLoadCode = {}
    table.insert(cnstLoadCode, " local _CONST = VM[2];")
    for idx = 1, #tree.Chunk.Const do
        local cnst = tree.Chunk.Const[idx]
        if type(cnst) == "number" then
            table.insert(cnstLoadCode, " VM({" .. serialize_number(cnst) .. "});")
        elseif type(cnst) == "boolean" then
            table.insert(cnstLoadCode, " VM(" .. tostring(cnst) .. ");")
        elseif type(cnst) == "table" and cnst.encrypted then
            table.insert(cnstLoadCode, " VM('IGNORE:" .. toEscStrBytes(cnst.data) .. "');")
        elseif type(cnst) == "string" then
            table.insert(cnstLoadCode, " VM('IGNORE:" .. toEscStrF(cnst) .. "');")
        elseif cnst == nil then
            table.insert(cnstLoadCode, " VM({nil});")
        end
    end
    local cnstLoadSrc = table.concat(cnstLoadCode, "\n")
    
    
    local getProtoLoadCode
    getProtoLoadCode = function(proto, protoIdx)
        local consts = {}
        for idx = 1, #proto.Const do
            local cnst = proto.Const[idx]
            if type(cnst) == "number" then
                table.insert(consts, serialize_number(cnst))
            elseif type(cnst) == "boolean" then
                table.insert(consts, tostring(cnst))
            elseif cnst == nil then
                table.insert(consts, "nil")
            elseif type(cnst) == "table" and cnst.encrypted then
                table.insert(consts, "'IGNORE:" .. toEscStrBytes(cnst.data) .. "'")
            elseif type(cnst) == "string" then
                table.insert(consts, "'IGNORE:" .. toEscStrF(cnst) .. "'")
            end
        end
        -- Serialize instructions as binary string (anti-SSTool)
        local protoInstStr = CreateInstDecoder(proto, scrambled_lookup, op_key_seed)
        local instField = "VM[5]('IGNORE:" .. toEscStrF(protoInstStr) .. "')"

        local protos = {}
        for idx = 1, #proto.Proto do
            table.insert(protos, getProtoLoadCode(proto.Proto[idx], protoIdx .. "." .. idx))
        end
        
        local upvalInfos = {}
        if proto.UpvalueInfo then
            for idx = 1, #proto.UpvalueInfo do
                local uv = proto.UpvalueInfo[idx]
                table.insert(upvalInfos, "{ " .. tostring(uv.instack) .. ", " .. tostring(uv.idx) .. " }")
            end
        end
        
        return "{\n" ..
               "                [1] = { [-1] = " .. #consts .. ", " .. table.concat(consts, ", ") .. " },\n" ..
               "                [2] = " .. instField .. ",\n" ..
               "                [3] = { " .. table.concat(protos, ";\n") .. " },\n" ..
               "                [4] = " .. tostring(proto.Upvals) .. ",\n" ..
               "                [5] = { " .. table.concat(upvalInfos, ", ") .. " },\n" ..
               "                [6] = " .. tostring(proto.Args) .. "\n" ..
               "            }"
    end
    
    local protoLoadCode = {}
    table.insert(protoLoadCode, " local _PROTO = VM[3];")
    for idx = 1, #tree.Chunk.Proto do
        local proto = tree.Chunk.Proto[idx]
        table.insert(protoLoadCode, "VM (" .. getProtoLoadCode(proto, tostring(idx)) .. ")")
    end
    local protoLoadSrc = table.concat(protoLoadCode, "\n")
    
    local vmTemplate = [=[
    ;
    local function new(signature, size_constinst, chunk_or_upvals, env, uvals)
        local OpcodeList = { OP_LIST_PLACEHOLDER }
        local op_key_seed = |OP_KEY_SEED|
        local Chunk = {}
        local current = nil
        local ran = false
        local InstLen = 1
        local ConstLen = 0
        local ProtoLen = 0
        local isClosure = false
        local Upvalues = nil
        local Lupvals = nil
        ;
        if (signature == 0 and size_constinst == "|OP_CLOSURE|") then
            isClosure = true
        end
;
        local function make_secure_consts(tbl)
            local backing = {}
            for k, v in pairs(tbl) do
                backing[k] = v
                tbl[k] = nil
            end
            setmetatable(tbl, {
                __index = function(self, k)
                    local val = backing[k]
                    if type(val) == 'string' then
                        return xorStr(val, xorDecodeckey)
                    end
                    return val
                end,
                __newindex = function(self, k, v)
                    backing[k] = v
                end
            })
        end
;
        local function decode_arg(str, p, bytes_len)
            local t = byte(str, p)
            p = p + 1
            if t == 0 then
                return nil, p
            elseif t == 1 then
                return false, p
            elseif t == 2 then
                return true, p
            else
                local val = 0
                local factor = 1
                for i = 1, bytes_len do
                    val = val + byte(str, p) * factor
                    factor = factor * 256
                    p = p + 1
                end
                return val, p
            end
        end
        ;
        local function decode_inst(str, inst_key)
            local p = 1
            local op_idx = byte(str, p)
            op_idx = BitXOR(op_idx, inst_key)
            
            local inst_type = byte(str, p + 1)
            p = p + 2
            
            local inst = {}
            inst['opcode'] = OpcodeList[op_idx]
            ;
            if inst_type == 1 then -- ABC
                local a, b, c, val
                a, p = decode_arg(str, p, 1)
                ;
                b, p = decode_arg(str, p, 2)
                ;
                c, p = decode_arg(str, p, 2)
                val, p = decode_arg(str, p, 5)
                inst[1] = a
                inst[2] = b
                inst[3] = c
                inst['__value__'] = val
            elseif inst_type == 2 then -- ABx
                local a, b, val
                a, p = decode_arg(str, p, 1)
                b, p = decode_arg(str, p, 4)
                val, p = decode_arg(str, p, 5)
                inst[1] = a
                inst[2] = b
                ;
                inst['__value__'] = val
            elseif inst_type == 3 then -- AsBx
                local a, b, val
                a, p = decode_arg(str, p, 1)
                ;
                b, p = decode_arg(str, p, 4)
                b = b - 131071
                val, p = decode_arg(str, p, 5)
                inst[1] = a
                inst[2] = b
                inst['__value__'] = val
            elseif inst_type == 4 then -- Ax
            ;
                local ax, val
                ax, p = decode_arg(str, p, 4)
                val, p = decode_arg(str, p, 5)
                inst[2] = ax
                inst['__value__'] = val
            elseif inst_type == 5 or inst_type == 6 then -- SOP / NOP
                local val
                val, p = decode_arg(str, p, 5)
                ;
                inst['__value__'] = val
            end
            return inst
        end

        -- Table-based instruction decoder for proto chunks
        local function decodeTableInst(inst_tbl, inst_key)
            local function to_num(v)
                if type(v) == 'string' then
                    return tonumber(v)
                end
                return v
            end
            ;
            if not inst_tbl then
                print("decodeTableInst error: inst_tbl is nil!")
            else
                local op = inst_tbl[0]
                if not op then
                    print("decodeTableInst error: opcode is nil! inst_key:", inst_key)
                    for k, v in pairs(inst_tbl) do
                        print("  ", tostring(k), "=", tostring(v))
                    end
                end
            end
            local op_idx = to_num(inst_tbl[0])
            op_idx = BitXOR(op_idx, inst_key)
            local result = {}
            result[0] = OpcodeList[op_idx]
            result[1] = to_num(inst_tbl[1]);
            result[2] = to_num(inst_tbl[2]);
            result[3] = to_num(inst_tbl[3]);
            result[4] = to_num(inst_tbl[4]);
            return result
        end
;
        local function decodeProtoInst(str)
            local p = 1
            local l = #str
            local inst = {}
            local inst_idx = 1
            local byte = byte
            local BitXOR = BitXOR
            ;
            local function decode_arg(str, p, bytes_len)
                local t = byte(str, p)
                p = p + 1
                if t == 0 then
                    return nil, p
                elseif t == 1 then
                    return false, p
                elseif t == 2 then
                    return true, p
                else
                    local val = 0
                    local factor = 1
                    for i = 1, bytes_len do
                        val = val + byte(str, p) * factor;
                        factor = factor * 256;
                        p = p + 1;
                    end
                    return val, p
                end
            end

            while p <= l do
                local op_idx_low = byte(str, p);
                local op_idx_high = byte(str, p + 1)
                local op_idx = op_idx_low + op_idx_high * 256;
                local inst_type = byte(str, p + 2)
                p = p + 3;
                
                local raw_inst = {}
                raw_inst[0] = op_idx
                
                if inst_type == 1 then -- ABC
                    local a, b, c, val
                    a, p = decode_arg(str, p, 1)
                    b, p = decode_arg(str, p, 2);
                    c, p = decode_arg(str, p, 2)
                    val, p = decode_arg(str, p, 5);
                    raw_inst[1] = a
                    raw_inst[2] = b
                    raw_inst[3] = c;
                    raw_inst[4] = val
                elseif inst_type == 2 then -- ABx
                    local a, b, val
                    a, p = decode_arg(str, p, 1);
                    b, p = decode_arg(str, p, 4)
                    val, p = decode_arg(str, p, 5)
                    raw_inst[1] = a;
                    raw_inst[2] = b
                    raw_inst[4] = val;
                elseif inst_type == 3 then -- AsBx
                    local a, b, val
                    a, p = decode_arg(str, p, 1)
                    b, p = decode_arg(str, p, 4);
                    b = b - 131071
                    val, p = decode_arg(str, p, 5)
                    raw_inst[1] = a;
                    raw_inst[2] = b
                    raw_inst[4] = val
                elseif inst_type == 4 then -- Ax
                    local ax, val;
                    ax, p = decode_arg(str, p, 4)
                    val, p = decode_arg(str, p, 5);
                    raw_inst[2] = ax
                    raw_inst[4] = val
                elseif inst_type == 5 or inst_type == 6 then -- SOP / NOP
                    local val
                    val, p = decode_arg(str, p, 5);
                    raw_inst[4] = val;
                end
                ;
                inst[inst_idx] = decodeTableInst(raw_inst, BitXOR(inst_idx % 256, op_key_seed))
                inst_idx = inst_idx + 1;
            end
            inst[-1] = inst_idx;
            return inst
        end

        |CHUNK_INIT_CF|
        local Env = (isClosure == true and env) or (isClosure == false and uvals or a()) or {}
        |INIT_CF|
        Chunk.Env = Env;
        
        local Metamethods = {
            __index = function(self, index)
                if (ran) then
                    return
                elseif (Chunk == nil) then
                    Chunk = {}
                end
                |INDEX_CF|
                return self
            end,
            __call = function(self, arg, A, B, C, D)
                if (ran) then
                    return error('Already ran!')
                end
                if (current == 1) then
                    |INST_LOADER_CF|
                elseif (current == 2) then
                    if (type(arg) == 'table') then
                        |CONST_TABLE_CF|
                    else
                        |CONST_OTHER_CF|
                    end
                elseif (current == 3) then
                    local function fix(whatfix)
                        local const = {};
                        local constL = 0;
                        local constCount = whatfix[1][-1] or #whatfix[1]
                        for i = 1, constCount do
                            const[constL] = whatfix[1][i]
                            constL = constL + 1
                        end;
                        const[-1] = constL
                        
                        if xorDecodeckey then
                            const.secured = true
                            make_secure_consts(const)
                        end
                        whatfix[1] = const;
                        
                        -- inst is pre-decoded by decodeProtoInst
                        
                        local proto = {};
                        local protoL = 0;
                        for i = 1, #whatfix[3] do
                            proto[protoL] = fix(whatfix[3][i])
                            protoL = protoL + 1
                        end
                        whatfix[3] = proto
                        whatfix[3][-1] = protoL

                        return whatfix
                    end
                    |PROTO_CF|
                elseif (current == 4) then
                    while (arg > -1) do
                        |INIT_DECOY_CF|
                    end
                end
                return self;
            end
        }
        
        local function Run(self_f, ...)
            if (isClosure ~= true and ran) then
                return error('Already ran!')
            else
                ran = true
            end
            
            if xorDecodeckey and Chunk[1] and not Chunk[1].secured then
                Chunk[1].secured = true
                make_secure_consts(Chunk[1]);
            end
            ;
            local Env = (self_f and type(self_f) == "table" and self_f.Env) or Chunk.Env
            local pc, Top = 1, -1
            local GStack = {}
            local Stack = setmetatable({}, {
                __index = GStack,
                __newindex = function(_, Key, Value)
                    if (Key > Top) then
                        Top = Key;
end;
                    GStack[Key] = Value;
                end;
            });
            
            local ArgCount = select('#', ...);
            local Vararg, Varargsz = {}, ArgCount - Chunk[6] - 1;
            local Args = {...};
            
            for Idx = 0, ArgCount - 1 do
                if (Idx >= Chunk[6]) then
                    Vararg[Idx - Chunk[6]] = Args[Idx + 1];
                else
                    Stack[Idx] = Args[Idx + 1];
                end;
            end;
            
            local function Loop()
                local ChunkConst = Chunk['IGNORE:const'];
                local Inst, enum;
                while true do
                    |LOOP_CF|
                end
            end
            
            local Result1, Result2 = Loop()
            if Result1 and (Result2 > 0) then
                return unpack(Result1, 1, Result2)
            end
            return
        end
        
        return setmetatable({}, Metamethods), Run
    end

    local VM, Wrapper = new("|Signature|", {CHUNK_CONST_LEN, CHUNK_INST_LEN}, CHUNK_UPVALS, a());
    VM[4](0, 'IGNORE:const', 'IGNORE:inst', 'IGNORE:proto', CHUNK_ARGS)

    -- Constants loading
    CONSTS_PLACEHOLDER

    -- Instructions deserializer
   ; local function decodeLoadStr(str)
        local _INST = VM[1];
        local p = 1
        local l = #str
        local byte = byte
        ;
        local function decode_arg(str, p, bytes_len)
            local t = byte(str, p)
            p = p + 1
            if t == 0 then
                return nil, p
            elseif t == 1 then
                return false, p
            elseif t == 2 then
                return true, p
            else
                local val = 0
                local factor = 1
                for i = 1, bytes_len do
                    val = val + byte(str, p) * factor;
                    factor = factor * 256;
                    p = p + 1
                end
                return val, p
            end
        end

        while p <= l do
            local op_idx_low = byte(str, p)
            local op_idx_high = byte(str, p + 1);
            local op_idx = op_idx_low + op_idx_high * 256;
            local inst_type = byte(str, p + 2);
            p = p + 3
            ;
            local inst = {}
            inst[0] = op_idx
            
            if inst_type == 1 then -- ABC
                local a, b, c, val
                a, p = decode_arg(str, p, 1);
                b, p = decode_arg(str, p, 2);
                c, p = decode_arg(str, p, 2);
                val, p = decode_arg(str, p, 5);
                inst[1] = a
                inst[2] = b;
                inst[3] = c;
                inst[4] = val;
            elseif inst_type == 2 then -- ABx
                local a, b, val
                a, p = decode_arg(str, p, 1)
                b, p = decode_arg(str, p, 4);
                val, p = decode_arg(str, p, 5);
                inst[1] = a;
                inst[2] = b
                inst[4] = val;
            elseif inst_type == 3 then -- AsBx
                local a, b, val
                a, p = decode_arg(str, p, 1)
                b, p = decode_arg(str, p, 4);
                b = b - 131071;
                val, p = decode_arg(str, p, 5)
                inst[1] = a;
                inst[2] = b
                inst[4] = val;
            elseif inst_type == 4 then -- Ax
                local ax, val
                ax, p = decode_arg(str, p, 4);
                val, p = decode_arg(str, p, 5)
                inst[2] = ax;
                inst[4] = val
            elseif inst_type == 5 or inst_type == 6 then -- SOP / NOP
                local val;
                val, p = decode_arg(str, p, 5);
                inst[4] = val
            end
            
            _INST(inst)
        end
    end
    MAIN_INST_TABLE_PLACEHOLDER
;
    -- Protos loading
    PROTOS_PLACEHOLDER
]=]

    local chunk_init_cf = cControlFlow({"Chunk = isClosure and chunk_or_upvals or {}"})
    
    local init_parts = {
        "ran = false;",
        "size_constinst = isClosure and ({}) or (size_constinst);",
        "Chunk[4] = isClosure and (Chunk[4]) or (chunk_or_upvals);",
        "Lupvals = {};",
        "InstLen = isClosure and (Chunk[2][-1]) or (1);",
        "ConstLen = isClosure and (Chunk[1][-1]) or (0);",
        "ProtoLen = (0);",
        "Upvalues = isClosure and uvals or {[0] = Env};"
    }
    shuffleArray(init_parts)
    local init_cf = cControlFlow(init_parts)

    local index_parts = {
        "if (index == 1) then current = index; end;",
        "if (index == 2) then current = index; end;",
        "if (index == 3) then current = index; end;",
        "if (index == 4) then current = index; end;",
        "if (index == 5) then return decodeProtoInst; end;"
    }
    shuffleArray(index_parts)
    local index_cf = cControlFlow(index_parts)

    local inst_loader_parts = {
        "Chunk[2][InstLen] = decodeTableInst(arg, BitXOR(InstLen % 256, op_key_seed));",
        "InstLen = InstLen + 1;"
    }
    local inst_loader_cf = cControlFlow(inst_loader_parts)

    local const_table_parts = {
        "Chunk[1][ConstLen] = arg[1]",
        "ConstLen = ConstLen + 1"
    }
    local const_table_cf = cControlFlow(const_table_parts)
    
    local const_other_parts = {
        "Chunk[1][ConstLen] = arg",
        "ConstLen = ConstLen + 1"
    }
    local const_other_cf = cControlFlow(const_other_parts)

    local proto_parts = {
        "Chunk[3][ProtoLen] = fix(arg);",
        "ProtoLen = ProtoLen + 1;"
    }
    local proto_cf = cControlFlow(proto_parts)

    local init_decoy_parts = {
        "Chunk[1] = Chunk[1] or {};",
        "Chunk[2] = Chunk[2] or {};",
        "Chunk[3] = Chunk[3] or {};",
        "Chunk[6] = D;",
        "arg = (arg * -1) - 50;"
    }
    shuffleArray(init_decoy_parts)
    local init_decoy_cf = cControlFlow(init_decoy_parts)

    local loop_parts = {
        "if (pc > (InstLen - 1)) then return end;",
        "Inst = Chunk[2][pc];",
        "enum = Inst[0];",
        "if enum == nil then error('DECRYPTION ERROR') end;",
        "pc = pc + 1;",
        "OPCODE_LADDER_PLACEHOLDER"
    }
    local loop_cf = cControlFlow(loop_parts)

    local s = vmTemplate
    s = plain_gsub(s, "|CHUNK_INIT_CF|", chunk_init_cf)
    s = plain_gsub(s, "|INIT_CF|", init_cf)
    s = plain_gsub(s, "|INDEX_CF|", index_cf)
    s = plain_gsub(s, "|INST_LOADER_CF|", inst_loader_cf)
    s = plain_gsub(s, "|CONST_TABLE_CF|", const_table_cf)
    s = plain_gsub(s, "|CONST_OTHER_CF|", const_other_cf)
    s = plain_gsub(s, "|PROTO_CF|", proto_cf)
    s = plain_gsub(s, "|INIT_DECOY_CF|", init_decoy_cf)
    s = plain_gsub(s, "|LOOP_CF|", loop_cf)

    s = plain_gsub(s, "OPCODE_LADDER_PLACEHOLDER", opcodeLadder)
    s = plain_gsub(s, "CHUNK_CONST_LEN", tostring(#tree.Chunk.Const))
    s = plain_gsub(s, "CHUNK_INST_LEN", tostring(#tree.Chunk.Instr))
    s = plain_gsub(s, "CHUNK_UPVALS", tostring(tree.Chunk.Upvals))
    s = plain_gsub(s, "CHUNK_ARGS", tostring(tree.Chunk.Args))
    s = plain_gsub(s, "CONSTS_PLACEHOLDER", cnstLoadSrc)
    s = plain_gsub(s, "PROTOS_PLACEHOLDER", protoLoadSrc)
    s = plain_gsub(s, "MAIN_INST_TABLE_PLACEHOLDER", mainInstTableSrc)
    
    -- Opcode template macros replacement
    s = plain_gsub(s, "|A|", "Inst[1]")
    s = plain_gsub(s, "|B|", "Inst[2]")
    s = plain_gsub(s, "|C|", "Inst[3]")
    s = plain_gsub(s, "|Bx|", "Inst[2]")
    s = plain_gsub(s, "|sBx|", "Inst[2]")
    s = plain_gsub(s, "|AIdx|", "1")
    s = plain_gsub(s, "|BIdx|", "2")
    s = plain_gsub(s, "|CIdx|", "3")
    s = plain_gsub(s, "|BxIdx|", "2")
    s = plain_gsub(s, "|sBxIdx|", "2")
    s = plain_gsub(s, "|OP_MOVE|", opmap["MOVE"])
    s = plain_gsub(s, "|OP_GETUPVAL|", opmap["GETUPVAL"])
    s = plain_gsub(s, "|OP_CLOSURE|", opmap["CLOSURE"])
    
    s = plain_gsub(s, "|XORDecodeCKey|", XORDecodeCKey)
    s = plain_gsub(s, "|Signature|", signature)
    s = plain_gsub(s, "|OP_KEY_SEED|", tostring(op_key_seed))
    s = plain_gsub(s, "OP_LIST_PLACEHOLDER", table.concat(opcode_list_elements, ", "))
    
    s = plain_gsub(s, "'|Inst|'", "2")
    s = plain_gsub(s, "\"|Inst|\"", "2")
    s = plain_gsub(s, "|Inst|", "2")
    
    s = plain_gsub(s, "'|Opcode|'", "0")
    s = plain_gsub(s, "\"|Opcode|\"", "0")
    s = plain_gsub(s, "|Opcode|", "0")
    
    s = plain_gsub(s, "'|Const|'", "1")
    s = plain_gsub(s, "\"|Const|\"", "1")
    s = plain_gsub(s, "|Const|", "1")
    
    s = plain_gsub(s, "'|Proto|'", "3")
    s = plain_gsub(s, "\"|Proto|\"", "3")
    s = plain_gsub(s, "|Proto|", "3")
    
    s = plain_gsub(s, "'|T_UPVALS|'", "4")
    s = plain_gsub(s, "\"|T_UPVALS|\"", "4")
    s = plain_gsub(s, "|T_UPVALS|", "4")
    
    s = plain_gsub(s, "'|Args|'", "6")
    s = plain_gsub(s, "\"|Args|\"", "6")
    s = plain_gsub(s, "|Args|", "6")
    
    s = plain_gsub(s, "'|UpvalInfo|'", "5")
    s = plain_gsub(s, "\"|UpvalInfo|\"", "5")
    s = plain_gsub(s, "|UpvalInfo|", "5")
    
    -- Anti-tamper placeholder replacement
    if settings.anti_tamper and not settings.debug then
        s = plain_gsub(s, "|VERIFY_FLAG|", anti_names.verify_flag)
    end
    
    s = plain_gsub(s, "InstrPoint", "pc")

    local watermarkText = settings.watermark or "Hello, Im Monetor"
    local wrapperKey = genChars(12)
    local XORSecondaryKey = genChars(11)
    local XORPrimaryKey = genChars(10)
    
    local stringCharIdx = genChars()
    local stringByteIdx = genChars()
    local stringGmatchIdx = genChars()
    local mtIdxStr = genChars()
    local xorName = genChars()
    local constMTableIndex = genChars()


    local function getCharCodes(str)
        local codes = {}
        for i = 1, #str do
            table.insert(codes, tostring(string.byte(str, i)))
        end
        return table.concat(codes, ", ")
    end

    local watermarkVar = genChars()
    local shitVar = genChars()
    local envFuncVar = genChars()
    local watermarkVarName = genChars()
    local constTableVar = genChars()

    local watermark_parts = {
        watermarkVar .. " = d;",
        shitVar .. " = d;",
        envFuncVar .. " = getfenv or function() return _ENV end;"
    }
    shuffleArray(watermark_parts)
    local watermark_cf = cControlFlow(watermark_parts)
    
    local wHeader = ";local " .. envFuncVar .. "," .. watermarkVarName .. "," .. constTableVar .. "=nil,nil,nil([[" .. watermarkText .. "]]):gsub('IGNORE:(.*)',function(d)\n;"
    
    local init_vars = {
        ';local ' .. watermarkVar .. ' = "IGNORE:' .. genChars(math.random(5, 25)) .. '";',
        ';local ' .. shitVar .. ' = "IGNORE:' .. genChars(math.random(5, 25)) .. '";'
    }
    shuffleArray(init_vars)
    wHeader = wHeader .. "    " .. table.concat(init_vars, "\n    ") .. "\n;"
    wHeader = wHeader .. "    " .. string.gsub(watermark_cf, "\n", "\n    ") .. "\n;"
    
    wHeader = wHeader .. "  ;  local " .. envFuncVar .. " = " .. envFuncVar .. "();\n"
    wHeader = wHeader .. "  ;  local d = " .. envFuncVar .. "[\"IGNORE:string\"][\"IGNORE:" .. toEscStrF("char") .. "\"](" .. getCharCodes("char") .. ")\n"
    wHeader = wHeader .. "  ;  local g = " .. envFuncVar .. "[string[d](" .. getCharCodes("string") .. ")];\n"
    
    local basic_vars = {
        'local j = "IGNORE:' .. genChars(math.random(5, 25)) .. '";',
        'local k = "IGNORE:' .. genChars(math.random(5, 25)) .. '";',
        'local h = "IGNORE:' .. genChars(math.random(5, 25)) .. '";'
    }
    shuffleArray(basic_vars)
    wHeader = wHeader .. "    " .. table.concat(basic_vars, "\n    ") .. "\n"
    
    local env_cf_parts = {
        "k = " .. envFuncVar .. "[g[d](" .. getCharCodes("string") .. ")][d];",
        "j = " .. envFuncVar .. "[g[d](" .. getCharCodes("string") .. ")][g[d](" .. getCharCodes("byte") .. ")];",
        "h = " .. envFuncVar .. "[g[d](" .. getCharCodes("string") .. ")][g[d](" .. getCharCodes("gmatch") .. ")];"
    }
    local env_cf = cControlFlow(env_cf_parts)
    wHeader = wHeader .. "    " .. string.gsub(env_cf, "\n", "\n    ") .. "\n;"
    
    wHeader = wHeader .. "    " .. constTableVar .. " = {\n"
    wHeader = wHeader .. "        [" .. watermarkVar .. "] = " .. #watermarkText .. ",\n"
    wHeader = wHeader .. "        ['IGNORE:" .. toEscStrF("_") .. "' .. k(" .. getCharCodes(watermarkText) .. ") ] = " .. shitVar .. "\n"
    wHeader = wHeader .. "    }\n"
    
    wHeader = wHeader .. "    " .. constTableVar .. "[g[d](" .. getCharCodes(stringByteIdx) .. ")] = j;\n;"
    wHeader = wHeader .. "    " .. constTableVar .. "[g[d](" .. getCharCodes(stringCharIdx) .. ")] = k;\n;"
    wHeader = wHeader .. "    " .. constTableVar .. "[g[d](" .. getCharCodes(stringGmatchIdx) .. ")] = h;\n;"
    
    local final_verify_parts = {
        ";if (" .. constTableVar .. "[" .. watermarkVar .. "] ~= nil and (#" .. shitVar .. " ~= " .. constTableVar .. "[" .. watermarkVar .. "])) then return 0; end;",
        ";if (k(" .. getCharCodes(watermarkText) .. ") ~= " .. watermarkVar .. ") then return false; end",
        ";if (" .. shitVar .. " ~= " .. constTableVar .. "['IGNORE:" .. toEscStrF("_") .. "' .. " .. watermarkVar .. "]) then return \"\"; end;",
        watermarkVarName .. " = " .. watermarkVar
    }
    local verify_cf = cControlFlow(final_verify_parts)
    wHeader = wHeader .. "    " .. string.gsub(verify_cf, "\n", "\n    ") .. "\n"
    
    wHeader = wHeader .. "    " .. watermarkVarName .. " = " .. watermarkVar .. ";\n"
    wHeader = wHeader .. "    " .. constTableVar .. "[" .. watermarkVar .. "] = nil;\n"
    wHeader = wHeader .. "end);\n"

    wHeader = wHeader .. ";local char = " .. constTableVar .. "[\"IGNORE:" .. stringCharIdx .. "\"];\n"
    wHeader = wHeader .. ";local byte = " .. constTableVar .. "[\"IGNORE:" .. stringByteIdx .. "\"];\n"
    wHeader = wHeader .. ";local gmatch = " .. constTableVar .. "[\"IGNORE:" .. stringGmatchIdx .. "\"];\n"

    wHeader = wHeader .. ";local string = " .. envFuncVar .. "()[char(" .. getCharCodes("string") .. ")];\n"
    wHeader = wHeader .. ";local format = string[char(" .. getCharCodes("format") .. ")];\n"
    wHeader = wHeader .. ";local sub = string[char(" .. getCharCodes("sub") .. ")];\n"
    wHeader = wHeader .. ";local next = " .. envFuncVar .. "()[char(" .. getCharCodes("next") .. ")];\n"
    wHeader = wHeader .. ";local concat = " .. envFuncVar .. "()[char(" .. getCharCodes("table") .. ")][char(" .. getCharCodes("concat") .. ")];\n"
    wHeader = wHeader .. ";local assert = " .. envFuncVar .. "()[char(" .. getCharCodes("assert") .. ")];\n"
    wHeader = wHeader .. ";local pairs = " .. envFuncVar .. "()[char(" .. getCharCodes("pairs") .. ")];\n"
    wHeader = wHeader .. ";local len = string[char(" .. getCharCodes("len") .. ")];\n"
    wHeader = wHeader .. ";local rawget = " .. envFuncVar .. "()[char(" .. getCharCodes("rawget") .. ")];\n"
    wHeader = wHeader .. ";local unpack = unpack or table.unpack;\n"

    wHeader = wHeader .. ";local charactertable = {}\n"
    wHeader = wHeader .. ";local basedictdecompress = {}\n"
    wHeader = wHeader .. "for i = 0, 255 do\n"
    wHeader = wHeader .. "    local ic, iic = char(i), char(i, 0)\n"
    wHeader = wHeader .. "    charactertable[ic] = iic\n"
    wHeader = wHeader .. "    basedictdecompress[iic] = ic\n"
    wHeader = wHeader .. "end\n"

    wHeader = wHeader .. constTableVar .. "[\"IGNORE:" .. stringByteIdx .. "\"] = nil;\n"
    wHeader = wHeader .. constTableVar .. "[\"IGNORE:" .. stringCharIdx .. "\"] = nil;\n"
    wHeader = wHeader .. constTableVar .. "[\"IGNORE:" .. stringGmatchIdx .. "\"] = nil;\n"
    wHeader = wHeader .. ";local sub = " .. envFuncVar .. "()[char(" .. getCharCodes("string") .. ")][char(" .. getCharCodes("sub") .. ")];\n"
    wHeader = wHeader .. ";local constMTableIndex = \"IGNORE:" .. mtIdxStr .. "\";\n"

    local decoy_helpers = {
        [[;local getAWord = function(len, str, wordindex, Environment)
            len = len or 1
            local word = Environment["|Stringsub|"](str, wordindex, domath(wordindex, domath(len, 1, "|SUB|"), "|ADD|")) 
            wordindex = domath(wordindex, len, "|ADD|") 
            return word
        end]],
        [[;local getBWord = function(str, wordindex, Environment)
            local left, right = Environment["|Stringbyte|"](str, wordindex, wordindex + 1)
            wordindex = wordindex + 2
            return (right * 256) + left
        end]],
        [[;local getCWord = function(str, wordindex, Environment)
            local left, right, front = Environment["|Stringbyte|"](str, wordindex, wordindex + 2)
            wordindex = wordindex + 3
            return (front * 65536) + (right * 256) + left
        end]],
        [[;local getDWord = function(str, wordindex, Environment)
            local left, right, front, back = Environment["|Stringbyte|"](str, wordindex, wordindex + 3)
            wordindex = wordindex + 4
            return (back * 16777216) + (front * 65536) + (right * 256) + left;
        end]],
        [[;local getQWord = function(str, wordindex, Environment)
            local left, right, front, back, top = Environment["|Stringbyte|"](str, wordindex, wordindex + 4)
            wordindex = wordindex + 5
            return (back * 16777216) + (front * 65536) + (right * 256) + left + (top * 4294967296);
        end]],
        [[;local function _antiDecompile()
            local _ = 1; local _ = 2; local _ = 3; local _ = 4; local _ = 5;
            local _ = 6; local _ = 7; local _ = 8; local _ = 9; local _ = 10;
            local _ = 11; local _ = 12; local _ = 13; local _ = 14; local _ = 15;
            local _ = 16; local _ = 17; local _ = 18; local _ = 19; local _ = 20;
            return _ + _
        end]]
    }
    shuffleArray(decoy_helpers)
    
    local decoy_code = "local domath = function(...) return ... end;\n"
    decoy_code = decoy_code .. "local wordindex = 0;\n"
    decoy_code = decoy_code .. "local environment = {''}\n"
    decoy_code = decoy_code .. table.concat(decoy_helpers, "\n") .. "\n"
    
    decoy_code = decoy_code .. [[
local function check(val, val2, statement)
    assert(statement, "How it works? - Monetor")
    if statement == "|EQ|" then
        return val == val2
    elseif statement == "|LT|" then
        return val < val2
    elseif statement == "|LE|" then
        return val <= val2
    end
end

local function domath(val, val2, statement)
    assert(statement, "How it works? - Monetor")
    if check(statement, "|MUL|", "|EQ|") then 
        return val * val2
    elseif check(statement, "|DIV|", "|EQ|") then 
        return val / val2
    elseif check(statement, "|ADD|", "|EQ|") then 
        return val + val2
    elseif check(statement, "|SUB|", "|EQ|") then 
        return val - val2
    elseif check(statement, "|MOD|", "|EQ|") then 
        return val % val2
    elseif check(statement, "|POW|", "|EQ|") then 
        return val ^ val2
    end
end

local function reverser(val, statement)
    assert(statement, "How it works? - Monetor")
    if check(statement, "|UNM|", "|EQ|") then 
        return -val
    elseif check(statement, "|NOT|", "|EQ|") then 
        return not val
    elseif check(statement, "|LEN|", "|EQ|") then 
        return #val
    end
end

local function concat(val, val2, statement)
    assert(statement, "How it works? - Monetor")
    if check(statement, "|CONCATSTRING|", "|EQ|") then 
        return val .. val2
    elseif check(statement, "|CONCATTABLE|", "|EQ|") then 
        return concat(val, val2)
    end
end
]]

    local bitxor_code = [[
local chartbl = {}
local BitXOR, XORString, XORTable, XORString1Fake, XORTable1Fake
]]
    
    local xor_fakes = {
        [[;XORString1Fake = function(str, key)
            local res = "IGNORE:";
            local a = 1
            for i = 1, #str do
                local xored = BitXOR(byte(sub(str, i, i)), byte(sub(key, a, a)) )
                res = res .. rawget(chartbl, xored) or xored
                a = a + 1;
                if a > #key then
                    a = 1
                end
            end
            return res
        end;]],
        [[;XORTable1Fake = function(tabl, key)
            local res = "IGNORE:";
            local a = 1
            for i = 1, #tabl do
                local xored = BitXOR(tabl[i], byte(sub(key, a, a)) )
                res = res .. chartbl[xored] or xored
                a = a + 1;
                if a > #key then
                    a = 1;
                end
            end
            return res
        end;]]
    }
    shuffleArray(xor_fakes)
    bitxor_code = bitxor_code .. cControlFlow(xor_fakes) .. "\n"
    
    bitxor_code = bitxor_code .. [[
;BitXOR = function(a, b) --Bitwise xor
    local p, c = 1, 0
    while a > 0 and b > 0 do
        local ra, rb = a % 2, b % 2;
        if ra ~= rb then c = c + p end
        a, b, p = math.floor((a - ra) / 2), math.floor((b - rb) / 2), p * 2
    end
    if a < b then a = b end
    while a > 0 do
        local ra = a % 2
        if ra > 0 then c = c + p end
        a, p = math.floor((a - ra) / 2), p * 2
    end
    return c
end;
;
for i, v in pairs(charactertable) do
    chartbl[byte(i)] = i
end
]]

    local xor_reals = {
        [[;XORString = function(str, key)
            local res = "IGNORE:";
            local a = 1
            for i = 1, #str do
                local xored = BitXOR(byte(sub(str, i, i)), byte(sub(key, a, a)) )
                res = res .. rawget(chartbl, xored) or xored
        a = a + 1;
                if a > #key then
                    a = 1
                end
            end
            return res
        end;]],
        [[;XORTable = function(tabl, key)
            local res = "IGNORE:";
            local a = 1
            for i = 1, #tabl do
                local xored = BitXOR(tabl[i], byte(sub(key, a, a)) )
                res = res .. chartbl[xored] or xored;
                a = a + 1;
                if a > #key then
                    a = 1;
                end
            end
            return res
        end;]]
    }
    shuffleArray(xor_reals)
    bitxor_code = bitxor_code .. cControlFlow(xor_reals) .. "\n"

    local number_table_setup = [[
local NumberTable = { {}, {} }
local TrackNumberTable = 1
for i = 1, 255 do
    if i >= 112 then
        NumberTable[2][TrackNumberTable] = i;
        TrackNumberTable = TrackNumberTable + 1
    else
        NumberTable[1][i] = i;
    end
end
;local characters = char(unpack(NumberTable[1])) .. char(unpack(NumberTable[2]));
]]
    
    local keys_vars = {
        'xorSecondaryKey', 'XORStringPrim', 'XORStringSec', 'xorPrimaryKey', 'xorDecodeckey', 'XORStringPrim1', 'XORTableSec', 'xorStr'
    }
    shuffleArray(keys_vars)
    
    local key_dec = ";local " .. table.concat(keys_vars, ", ") .. ";\n"
    key_dec = key_dec .. ";xorSecondaryKey = XORTable({" .. table.concat(xorStrArr(XORSecondaryKey, wrapperKey), ", ") .. "}, \"IGNORE:" .. toEscStrF(wrapperKey) .. "\");\n"
    
    local key_cf_parts = {
        ";XORTableSec = function(...) return XORTable(..., xorSecondaryKey) end;",
        ";XORStringSec = function(a, ...) return XORString(a, xorSecondaryKey, ...) end;",
        ";XORStringPrim = function(a, ...) return XORString(a, xorPrimaryKey, ...) end;"
    }
    key_dec = key_dec .. cControlFlow(key_cf_parts) .. "\n"
    
    key_dec = key_dec .. ";xorPrimaryKey = XORTable({" .. table.concat(xorStrArr(XORPrimaryKey, wrapperKey), ", ") .. "}, \"IGNORE:" .. toEscStrF(wrapperKey) .. "\");\n;"
    if settings.encrypt_constants then
        key_dec = key_dec .. ";xorDecodeckey = XORTable({" .. table.concat(xorStrArr(XORDecodeCKey, wrapperKey), ", ") .. "}, \"IGNORE:" .. toEscStrF(wrapperKey) .. "\");\n;"
    else
        key_dec = key_dec .. "xorDecodeckey = nil;\n;"
    end
    
    key_dec = key_dec .. ";local _1 = byte(char(1));\n"
    key_dec = key_dec .. constTableVar .. "[\"IGNORE:" .. xorName .. "\"] = function(str, key)\n"
    key_dec = key_dec .. "    local res = char();\n"
    key_dec = key_dec .. "    local a = _1;\n"
    key_dec = key_dec .. "    for i = _1, #str do\n"
    key_dec = key_dec .. "        local xored = BitXOR( byte(sub(str, i, i)), byte(sub(key, a, a)) );\n"
    key_dec = key_dec .. "        res = res .. (rawget(chartbl, xored) or char(xored));\n"
    key_dec = key_dec .. "        a = a + _1;\n"
    key_dec = key_dec .. "        a = (a > #key and _1) or a;\n"
    key_dec = key_dec .. "    end;\n"
    key_dec = key_dec .. "    return res;\n"
    key_dec = key_dec .. "end;\n"
    
    key_dec = key_dec .. ";local xorStrS1 = " .. constTableVar .. "[XORTableSec({" .. table.concat(xorStrArr(xorName, XORSecondaryKey), ", ") .. "})];\n;"

    local env_vars = {
        "string", "pcall", "error", "table", "setmetatable", "tostring", "tonumber",
        "print", "type", "pairs", "select", "assert", "coroutine", "getmetatable", "rawget",
        "os", "debug", "io", "math", "utf8", "bit", "bit32", "load", "loadstring"
    }
    shuffleArray(env_vars)
    
    local env_load = "\n--START_ENV_LOAD\n"
    for _, name in ipairs(env_vars) do
        local xored = "{" .. table.concat(xorStrArr(name, XORSecondaryKey), ", ") .. "}"
        env_load = env_load .. ";local " .. name .. " = " .. envFuncVar .. "()[XORTableSec(" .. xored .. ")];\n"
    end
    env_load = env_load .. ";xorStr = " .. constTableVar .. "[\"IGNORE:" .. xorName .. "\"];\n"
    env_load = env_load .. "--END_ENV_LOAD\n"

    local wInnerVar = genChars()
    local envInnerVar = genChars()
    local amountArgsVar = genChars()

    local wrapper_src = ""
    wrapper_src = wrapper_src .. wHeader .. "\n"
    wrapper_src = wrapper_src .. decoy_code .. "\n"
    wrapper_src = wrapper_src .. bitxor_code .. "\n"
    wrapper_src = wrapper_src .. number_table_setup .. "\n"
    wrapper_src = wrapper_src .. key_dec .. "\n"
    
    wrapper_src = wrapper_src .. ";return (function(__ARG__)\n"
    wrapper_src = wrapper_src .. "    local " .. wInnerVar .. ", " .. envInnerVar .. ", " .. amountArgsVar .. ";\n"
    wrapper_src = wrapper_src .. "    " .. amountArgsVar .. " = (" .. amountArgsVar .. " or 0);\n"
    wrapper_src = wrapper_src .. "    for i, v in pairs(__ARG__) do\n;"
    wrapper_src = wrapper_src .. "        " .. amountArgsVar .. " = (" .. amountArgsVar .. " or 0) + 1\n"
    wrapper_src = wrapper_src .. "    end\n"
    wrapper_src = wrapper_src .. "    if (" .. amountArgsVar .. " < 2) then\n"
    wrapper_src = wrapper_src .. "        return \"IGNORE:vsQkvY_DaT\"\n"
    wrapper_src = wrapper_src .. "    end\n"

    local wrapper_arg_parts = {
        wInnerVar .. " = __ARG__[2];",
        envInnerVar .. " = __ARG__[1];"
    }
    wrapper_src = wrapper_src .. "    " .. cControlFlow(wrapper_arg_parts) .. "\n"
    
    wrapper_src = wrapper_src .. "    " .. constTableVar .. " = |ConstantTable|\n"
    wrapper_src = wrapper_src .. "    " .. constTableVar .. "[\"" .. xorName .. "\"] = xorStrS1;\n"
    
    wrapper_src = wrapper_src .. env_load .. "\n"
    
    wrapper_src = wrapper_src .. " ;   local cyield = coroutine;\n"
    wrapper_src = wrapper_src .. "    local function whatLineErr(...)\n"
    wrapper_src = wrapper_src .. "        local _, str = ...\n"
    wrapper_src = wrapper_src .. "     ;   if not str then return nil end\n"
    wrapper_src = wrapper_src .. "        str = tostring(str)\n"
    wrapper_src = wrapper_src .. "    ;    local Matched = gmatch(str, \":(%d+):\")()\n"
    wrapper_src = wrapper_src .. "        if not Matched then Matched = gmatch(str, \":(%d+)\")() end\n"
    wrapper_src = wrapper_src .. "    ;    if not Matched then Matched = gmatch(str, \"(%d+)\")() end\n"
    wrapper_src = wrapper_src .. "        return tonumber(Matched)\n"
    wrapper_src = wrapper_src .. "    end;\n"
    wrapper_src = wrapper_src .. "   ; local StartLine = whatLineErr(pcall(function() local a = \"a\" ^ 1 end));\n"
    wrapper_src = wrapper_src .. "    local function _Returns(...)\n"
    wrapper_src = wrapper_src .. "        return select('#', ...), {...};\n"
    wrapper_src = wrapper_src .. "    end;\n"

    local replaceWords = {
        Stringsub = genChars(),
        SUB = genChars(),
        ADD = genChars(),
        Stringbyte = genChars(),
        EQ = genChars(),
        LT = genChars(),
        LE = genChars(),
        MUL = genChars(),
        DIV = genChars(),
        MOD = genChars(),
        POW = genChars(),
        UNM = genChars(),
        NOT = genChars(),
        LEN = genChars(),
        CONCATSTRING = genChars(),
        CONCATTABLE = genChars()
    }
    
    for k, v in pairs(replaceWords) do
        wrapper_src = plain_gsub(wrapper_src, '"|' .. k .. '|"', '"' .. v .. '"')
        wrapper_src = plain_gsub(wrapper_src, "'|" .. k .. "|'", "'" .. v .. "'")
    end

    local decoys = {}
    local num_decoys = math.random(15, 30)
    for i = 1, num_decoys do
        local dkey = (math.random() * 500) - 250
        local dval = (math.random() * 200) - 100
        table.insert(decoys, "    [" .. string.format("%.16f", dkey) .. "] = " .. string.format("%.16f", dval) .. ";")
    end
    for i = 1, math.random(5, 10) do
        local dkey = genChars(math.random(5, 15))
        local dval = genChars(math.random(5, 20))
        table.insert(decoys, "    [\"IGNORE:" .. dkey .. "\"] = \"IGNORE:" .. dval .. "\";")
    end
    shuffleArray(decoys)

    local mt_decoys = {}
    for i = 1, math.random(2, 6) do
        local mkey = (math.random() * 500) - 250
        local mval = (math.random() * 200) - 100
        table.insert(mt_decoys, "            [" .. string.format("%.16f", mkey) .. "] = " .. string.format("%.16f", mval) .. ";")
    end
    
    s = plain_gsub(s, "a()", envFuncVar .. "()")
    local full_code = wrapper_src .. "\n" .. s .. "\n  ;  local my_env = getfenv and getfenv(1) or nil;\n ;   if my_env then VM.Env = my_env; end;\n    return Wrapper(VM, unpack(__ARG__, 3));\nend)( (function(...)\n   ; local t = {\n" .. table.concat(decoys, "\n") .. "\n    }\n;    local args = {...}\n    for i = 1, #args do\n        t[i + 2] = args[i]\n    end\n    return t\nend)(...) )\n"

    -- Write raw generated VM code before string extraction to temp/raw_vm.lua
    local raw_f = io.open("temp/raw_vm.lua", "w")
    if raw_f then
        raw_f:write(full_code)
        raw_f:close()
    end

    local final_code, arr = extract_strings(full_code, XORSecondaryKey, constTableVar)
    shuffleArray(arr)
    
    local tableStr = ""
    while #arr > 0 do
        local co = {}
        for i = 1, 5000 do
            local line = table.remove(arr, 1)
            if line then
                table.insert(co, line)
            else
                break
            end
        end
        tableStr = tableStr .. "\ndo\n" .. table.concat(co, "\n") .. "\nend;\n"
    end

    local cTableStr = "do\n"
    cTableStr = cTableStr .. " ;   local setmetatable = " .. envFuncVar .. "()[XORStringSec(\"" .. toEscStr(xorStrArr("setmetatable", XORSecondaryKey)) .. "\")];\n"
    cTableStr = cTableStr .. "    if (setmetatable ~= nil) then\n"
    cTableStr = cTableStr .. "        " .. constTableVar .. "[XORStringSec(\"" .. toEscStr(xorStrArr(mtIdxStr, XORSecondaryKey)) .. "\")] = setmetatable({\n"
    cTableStr = cTableStr .. table.concat(mt_decoys, "\n") .. "\n"
    cTableStr = cTableStr .. "        }, {\n"
    cTableStr = cTableStr .. "            [XORStringSec(\"" .. toEscStr(xorStrArr("__tostring", XORSecondaryKey)) .. "\")] = function(a, b)\n"
    cTableStr = cTableStr .. "                return (function()\n"
    cTableStr = cTableStr .. "                    while true do\n"
    cTableStr = cTableStr .. "                        " .. constTableVar .. " = " .. constTableVar .. " or nil;\n"
    cTableStr = cTableStr .. "                        if (" .. constTableVar .. " ~= nil and " .. constTableVar .. "[1] ~= nil) then\n"
    cTableStr = cTableStr .. "                            break\n"
    cTableStr = cTableStr .. "                        else\n"
    cTableStr = cTableStr .. "                            " .. constTableVar .. "[\"" .. toEscStrF(generateString(math.random(10, 25))) .. "\"] = \"" .. toEscStrF(generateString(math.random(10, 25))) .. "\";\n"
    cTableStr = cTableStr .. "                        end\n"
    cTableStr = cTableStr .. "                    end;\n"
    cTableStr = cTableStr .. "                    return \"" .. toEscStrF(generateString(math.random(15, 45))) .. "\";\n"
    cTableStr = cTableStr .. "                end)();\n"
    cTableStr = cTableStr .. "            end;\n"
    cTableStr = cTableStr .. "        });\n"
    cTableStr = cTableStr .. "        " .. constTableVar .. "[1] = " .. constTableVar .. "[constMTableIndex];\n"
    cTableStr = cTableStr .. "    end;\n"
    cTableStr = cTableStr .. tableStr .. "\nend;\n;"

    final_code = plain_gsub(final_code, "|ConstantTable|", "{ };\n" .. cTableStr)

    -- Removing the no-op blocks can leave empty statement separators at the
    -- beginning of generated lines. Lua 5.1 rejects leading semicolons, so
    -- discard only those separators while preserving normal statement ends.
    final_code = remove_empty_separators(final_code)

    local watermarkHeader = "-- تم التشفير بواسطة Monetor\n"

    final_code = minifier.obfuscate_names(final_code, vm_vars)
    final_code = remove_empty_separators(final_code)

    if settings.minify then
        final_code = minify(final_code)
    end

    final_code = watermarkHeader .. final_code

    return final_code
end

return generator_module
