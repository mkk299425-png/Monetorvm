-- Bytecode parser/decoder
local parser = {}

local Reader = require("src.parser.reader")
local opcodes = require("src.generator.opcodes")
local helpers = require("src.utils.helpers")

local bit_range = helpers.bit_range
local opdata_51 = opcodes.opdata_51
local opdata_52 = opcodes.opdata_52
local opdata_53 = opcodes.opdata_53

function parser.decode_bytecode(byteString)
    local reader = Reader.new(byteString)
    
    -- Detect Lua Version
    if string.sub(byteString, 1, 4) ~= "\27Lua" then
        error("Invalid Lua bytecode signature")
    end
    
    local version = string.byte(byteString, 5)
    local versionStr = "5.1"
    if version == 0x53 then
        versionStr = "5.3"
    elseif version == 0x52 then
        versionStr = "5.2"
    elseif version ~= 0x51 then
        print("Warning: Unsupported version 0x" .. string.format("%X", version) .. ", defaulting to 5.1 parser")
    end
    
    local Headers = {}
    local ChunkDecode
    
    if versionStr == "5.3" then
        Headers.Signature = reader:read(4)
        Headers.Version = reader:gBits8()
        Headers.Format = reader:gBits8()
        Headers.LuacData = reader:read(6)
        Headers.IntSize = reader:gBits8()
        Headers.SizetSize = reader:gBits8()
        Headers.InstructionSize = reader:gBits8()
        Headers.IntegerSize = reader:gBits8()
        Headers.NumberSize = reader:gBits8()
        
        reader.intSize = Headers.IntSize
        reader.sizetSize = Headers.SizetSize
        reader.instructionSize = Headers.InstructionSize
        reader.integerSize = Headers.IntegerSize
        reader.numberSize = Headers.NumberSize
        
        Headers.LuacInt = reader:gInteger()
        Headers.LuacNum = reader:gNumber()
        
        local mainUpvalues = reader:gBits8()
        
        local opdata = opdata_53
        
        ChunkDecode = function()
            local chunk = {
                Name = reader:gString53(),
                FirstL = reader:gInt(),
                LastL = reader:gInt(),
                Args = reader:gBits8(),
                Vargs = reader:gBits8(),
                Stack = reader:gBits8(),
                Instr = {},
                Const = {},
                Proto = {},
                Upvals = 0,
                UpvalueInfo = {},
                UsedInstructions = {}
            }
            
            -- Read Instructions
            local instLen = reader:gInt()
            local expectingExtraArg = false
            for idx = 1, instLen do
                local val = reader:gBits32()
                local opco = bit_range(val, 0, 6)
                local opname = opdata.Opnames[opco + 1]
                if not opname then
                    error(string.format("Invalid opcode decoded: %d (raw: 0x%08X) at instruction index %d/%d.\nVM info: BigEndian=%s, FirstL=%d, LastL=%d",
                        opco, val, idx, instLen, tostring(reader.bigEndian), chunk.FirstL, chunk.LastL))
                end
                local type_ = opdata.Opcode[opco]
                
                chunk.UsedInstructions[opname] = true
                
                local inst = {
                    Enum = opname,
                    Value = val,
                    Type = type_,
                    Name = opname,
                    References = {},
                    [1] = bit_range(val, 6, 8),
                    [2] = nil,
                    [3] = nil
                }
                
                if expectingExtraArg then
                    expectingExtraArg = false
                    inst.IsDataType = true
                    inst.Ax = bit_range(val, 6, 26)
                    chunk.Instr[idx] = inst
                else
                    if type_ == "ABC" then
                        inst[2] = bit_range(val, 23, 9) -- B
                        inst[3] = bit_range(val, 14, 9) -- C
                    elseif type_ == "ABx" then
                        inst[2] = bit_range(val, 14, 18) -- Bx
                    elseif type_ == "AsBx" then
                        inst[2] = bit_range(val, 14, 18) - 131071 -- sBx
                    elseif type_ == "Ax" then
                        inst.Ax = bit_range(val, 6, 26)
                    end
                    
                    if opname == "LOADKX" or (opname == "SETLIST" and inst[3] == 0) then
                        expectingExtraArg = true
                    end
                    if opname == "TEST" or opname == "TESTSET" then
                        inst[3] = inst[3] ~= 0
                    end
                    if opname == "EQ" or opname == "LT" or opname == "LE" then
                        inst[1] = inst[1] ~= 0
                    end
                    
                    chunk.Instr[idx] = inst
                end
            end
            
            -- Post-process instruction references (JMP points)
            for idx = 1, #chunk.Instr do
                local inst = chunk.Instr[idx]
                if inst.Name == "JMP" or inst.Name == "FORLOOP" or inst.Name == "FORPREP" or inst.Name == "TFORLOOP" then
                    local target = idx + inst[2] + 1
                    inst.References = { chunk.Instr[target] }
                elseif inst.Name == "EQ" or inst.Name == "LT" or inst.Name == "LE" or inst.Name == "TEST" or inst.Name == "TESTSET" then
                    local nextJmp = chunk.Instr[idx + 1]
                    if nextJmp and nextJmp.Name == "JMP" then
                        local target = idx + 1 + nextJmp[2] + 1
                        inst.References = { nil, nil, chunk.Instr[target] }
                    end
                end
            end
            
            -- Read Constants
            local constLen = reader:gInt()
            for idx = 1, constLen do
                local type_ = reader:gBits8()
                local cons = nil
                if type_ == 0 then -- nil
                    cons = nil
                elseif type_ == 1 then -- bool
                    cons = (reader:gBits8() ~= 0)
                elseif type_ == 3 then -- float
                    cons = reader:gNumber()
                elseif type_ == 19 then -- integer
                    cons = reader:gInteger()
                elseif type_ == 4 or type_ == 20 then -- string
                    cons = reader:gString53()
                end
                chunk.Const[idx] = cons
            end
            
            -- Read Upvalues Info
            local upvLen = reader:gInt()
            for idx = 1, upvLen do
                chunk.UpvalueInfo[idx] = {
                    instack = reader:gBits8(),
                    idx = reader:gBits8()
                }
            end
            chunk.Upvals = upvLen
            
            -- Read Protos
            local protoLen = reader:gInt()
            for idx = 1, protoLen do
                chunk.Proto[idx] = ChunkDecode()
            end
            
            -- Skip Debug Data
            local lineLen = reader:gInt()
            for i = 1, lineLen do reader:gInt() end
            local localLen = reader:gInt()
            for i = 1, localLen do
                reader:gString53()
                reader:gInt()
                reader:gInt()
            end
            local upvNameLen = reader:gInt()
            for i = 1, upvNameLen do reader:gString53() end
            
            return chunk
        end
        
        local tree = { Headers = Headers, LuaVersion = "5.3" }
        tree.Chunk = ChunkDecode()
        tree.Chunk.Upvals = mainUpvalues
        return tree
        
    elseif versionStr == "5.2" then
        Headers.Signature = reader:read(4)
        Headers.Version = reader:gBits8()
        Headers.Format = reader:gBits8()
        Headers.Endianness = reader:gBits8()
        reader.bigEndian = (Headers.Endianness == 0)
        Headers.IntSize = reader:gBits8()
        Headers.SizetSize = reader:gBits8()
        Headers.InstructionSize = reader:gBits8()
        Headers.NumberSize = reader:gBits8()
        Headers.IntegralFlag = reader:gBits8()
        Headers.LuacData = reader:read(6)
        
        reader.intSize = Headers.IntSize
        reader.sizetSize = Headers.SizetSize
        
        local opdata = opdata_52
        
        ChunkDecode = function()
            local chunk = {
                Name = nil,
                FirstL = reader:gInt(),
                LastL = reader:gInt(),
                Args = reader:gBits8(),
                Vargs = reader:gBits8(),
                Stack = reader:gBits8(),
                Instr = {},
                Const = {},
                Proto = {},
                Upvals = 0,
                UpvalueInfo = {},
                UsedInstructions = {}
            }
            
            -- Read Instructions
            local instLen = reader:gInt()
            local expectingExtraArg = false
            for idx = 1, instLen do
                local val = reader:gBits32()
                local opco = bit_range(val, 0, 6)
                local opname = opdata.Opnames[opco + 1]
                if not opname then
                    error(string.format("Invalid opcode decoded: %d (raw: 0x%08X) at instruction index %d/%d.\nVM info: BigEndian=%s, FirstL=%d, LastL=%d",
                        opco, val, idx, instLen, tostring(reader.bigEndian), chunk.FirstL, chunk.LastL))
                end
                local type_ = opdata.Opcode[opco]
                
                chunk.UsedInstructions[opname] = true
                
                local inst = {
                    Enum = opname,
                    Value = val,
                    Type = type_,
                    Name = opname,
                    References = {},
                    [1] = bit_range(val, 6, 8),
                    [2] = nil,
                    [3] = nil
                }
                
                if expectingExtraArg then
                    expectingExtraArg = false
                    inst.IsDataType = true
                    inst.Ax = bit_range(val, 6, 26)
                    chunk.Instr[idx] = inst
                else
                    if type_ == "ABC" then
                        inst[2] = bit_range(val, 23, 9) -- B
                        inst[3] = bit_range(val, 14, 9) -- C
                    elseif type_ == "ABx" then
                        inst[2] = bit_range(val, 14, 18) -- Bx
                    elseif type_ == "AsBx" then
                        inst[2] = bit_range(val, 14, 18) - 131071 -- sBx
                    elseif type_ == "Ax" then
                        inst.Ax = bit_range(val, 6, 26)
                    end
                    
                    if opname == "LOADKX" or (opname == "SETLIST" and inst[3] == 0) then
                        expectingExtraArg = true
                    end
                    if opname == "TEST" or opname == "TESTSET" then
                        inst[3] = inst[3] ~= 0
                    end
                    if opname == "EQ" or opname == "LT" or opname == "LE" then
                        inst[1] = inst[1] ~= 0
                    end
                    
                    chunk.Instr[idx] = inst
                end
            end
            
            -- Post-process instruction references (JMP points)
            for idx = 1, #chunk.Instr do
                local inst = chunk.Instr[idx]
                if inst.Name == "JMP" or inst.Name == "FORLOOP" or inst.Name == "FORPREP" or inst.Name == "TFORLOOP" then
                    local target = idx + inst[2] + 1
                    inst.References = { chunk.Instr[target] }
                elseif inst.Name == "EQ" or inst.Name == "LT" or inst.Name == "LE" or inst.Name == "TEST" or inst.Name == "TESTSET" then
                    local nextJmp = chunk.Instr[idx + 1]
                    if nextJmp and nextJmp.Name == "JMP" then
                        local target = idx + 1 + nextJmp[2] + 1
                        inst.References = { nil, nil, chunk.Instr[target] }
                    end
                end
            end
            
            -- Read Constants
            local constLen = reader:gInt()
            for idx = 1, constLen do
                local type_ = reader:gBits8()
                local cons = nil
                if type_ == 0 then -- nil
                    cons = nil
                elseif type_ == 1 then -- bool
                    cons = (reader:gBits8() ~= 0)
                elseif type_ == 3 then -- float (double)
                    cons = reader:gNumber()
                elseif type_ == 4 then -- string
                    cons = reader:gString51()
                elseif type_ == 254 then -- LUA_TINT (Luaj custom integer)
                    cons = reader:gInt()
                end
                chunk.Const[idx] = cons
            end
            
            -- Read Protos
            local protoLen = reader:gInt()
            for idx = 1, protoLen do
                chunk.Proto[idx] = ChunkDecode()
            end
            
            -- Read Upvalues Info
            local upvLen = reader:gInt()
            for idx = 1, upvLen do
                chunk.UpvalueInfo[idx] = {
                    instack = reader:gBits8(),
                    idx = reader:gBits8()
                }
            end
            chunk.Upvals = upvLen
            
            -- Skip Debug Data
            chunk.Name = reader:gString51()
            
            local lineLen = reader:gInt()
            for i = 1, lineLen do reader:gInt() end
            local localLen = reader:gInt()
            for i = 1, localLen do
                reader:gString51()
                reader:gInt()
                reader:gInt()
            end
            local upvNameLen = reader:gInt()
            for i = 1, upvNameLen do reader:gString51() end
            
            return chunk
        end
        
        local tree = { Headers = Headers, LuaVersion = "5.2" }
        tree.Chunk = ChunkDecode()
        return tree
        
    else -- Lua 5.1
        Headers.Signature = reader:read(4)
        Headers.Version = reader:gBits8()
        Headers.Format = reader:gBits8()
        Headers.Endianness = reader:gBits8()
        reader.bigEndian = (Headers.Endianness == 0)
        Headers.IntSize = reader:gBits8()
        Headers.SizetSize = reader:gBits8()
        Headers.InstructionSize = reader:gBits8()
        Headers.NumberSize = reader:gBits8()
        Headers.IntegralFlag = reader:gBits8()
        
        reader.intSize = Headers.IntSize
        reader.sizetSize = Headers.SizetSize
        
        local opdata = opdata_51
        
        ChunkDecode = function()
            local chunk = {
                Name = reader:gString51(),
                FirstL = reader:gInt(),
                LastL = reader:gInt(),
                Upvals = reader:gBits8(),
                Args = reader:gBits8(),
                Vargs = reader:gBits8(),
                Stack = reader:gBits8(),
                Instr = {},
                Const = {},
                Proto = {},
                UsedInstructions = {}
            }
            
            -- Read Instructions
            local instLen = reader:gInt()
            local expectingSetListData = false
            for idx = 1, instLen do
                local val = reader:gBits32()
                local opco = bit_range(val, 0, 6)
                local opname = opdata.Opnames[opco + 1]
                local type_ = opdata.Opcode[opco]
                
                chunk.UsedInstructions[opname] = true
                
                local inst = {
                    Enum = opname,
                    Value = val,
                    Type = type_,
                    Name = opname,
                    References = {},
                    [1] = bit_range(val, 6, 8),
                    [2] = nil,
                    [3] = nil
                }
                
                if expectingSetListData then
                    expectingSetListData = false
                    inst.IsDataType = true
                    chunk.Instr[idx] = inst
                else
                    if type_ == "ABC" then
                        inst[2] = bit_range(val, 23, 9) -- B
                        inst[3] = bit_range(val, 14, 9) -- C
                    elseif type_ == "ABx" then
                        inst[2] = bit_range(val, 14, 18) -- Bx
                    elseif type_ == "AsBx" then
                        inst[2] = bit_range(val, 14, 18) - 131071 -- sBx
                    end
                    
                    if opname == "SETLIST" and inst[3] == 0 then
                        expectingSetListData = true
                    end
                    if opname == "TEST" or opname == "TESTSET" then
                        inst[3] = inst[3] ~= 0
                    end
                    if opname == "EQ" or opname == "LT" or opname == "LE" then
                        inst[1] = inst[1] ~= 0
                    end
                    
                    chunk.Instr[idx] = inst
                end
            end
            
            -- Post-process instruction references (JMP points)
            for idx = 1, #chunk.Instr do
                local inst = chunk.Instr[idx]
                if inst.Name == "JMP" or inst.Name == "FORLOOP" or inst.Name == "FORPREP" then
                    local target = idx + inst[2] + 1
                    inst.References = { chunk.Instr[target] }
                elseif inst.Name == "EQ" or inst.Name == "LT" or inst.Name == "LE" or inst.Name == "TEST" or inst.Name == "TESTSET" then
                    local nextJmp = chunk.Instr[idx + 1]
                    if nextJmp and nextJmp.Name == "JMP" then
                        local target = idx + 1 + nextJmp[2] + 1
                        inst.References = { nil, nil, chunk.Instr[target] }
                    end
                end
            end
            
            -- Read Constants
            local constLen = reader:gInt()
            for idx = 1, constLen do
                local type_ = reader:gBits8()
                local cons = nil
                if type_ == 1 then -- bool
                    cons = (reader:gBits8() ~= 0)
                elseif type_ == 3 then -- number (double)
                    cons = reader:gNumber()
                elseif type_ == 4 then -- string
                    cons = reader:gString51()
                end
                chunk.Const[idx] = cons
            end
            
            -- Read Protos
            local protoLen = reader:gInt()
            for idx = 1, protoLen do
                chunk.Proto[idx] = ChunkDecode()
            end
            
            -- Skip Debug Data
            local lineLen = reader:gInt()
            for i = 1, lineLen do reader:gInt() end
            local localLen = reader:gInt()
            for i = 1, localLen do
                reader:gString51()
                reader:gInt()
                reader:gInt()
            end
            local upvNameLen = reader:gInt()
            for i = 1, upvNameLen do reader:gString51() end
            
            return chunk
        end
        
        local tree = { Headers = Headers, LuaVersion = "5.1" }
        tree.Chunk = ChunkDecode()
        return tree
    end
end

return parser
