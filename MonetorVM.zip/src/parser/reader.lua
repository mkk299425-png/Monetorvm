-- Byte stream Reader
local Reader = {}
Reader.__index = Reader

function Reader.new(str)
    return setmetatable({ str = str, p = 1, bigEndian = false }, Reader)
end

function Reader:gByte()
    local val = string.byte(self.str, self.p)
    self.p = self.p + 1
    return val or 0
end

function Reader:read(len)
    local val = string.sub(self.str, self.p, self.p + len - 1)
    self.p = self.p + len
    return val
end

function Reader:gBits8()
    return self:gByte()
end

function Reader:gBits32()
    local b1 = self:gByte()
    local b2 = self:gByte()
    local b3 = self:gByte()
    local b4 = self:gByte()
    if self.bigEndian then
        return b4 + b3 * 256 + b2 * 65536 + b1 * 16777216
    else
        return b1 + b2 * 256 + b3 * 65536 + b4 * 16777216
    end
end

function Reader:gBits64()
    if self.bigEndian then
        local high = self:gBits32()
        local low = self:gBits32()
        return low + high * 4294967296
    else
        local low = self:gBits32()
        local high = self:gBits32()
        return low + high * 4294967296
    end
end

function Reader:gInt()
    if self.intSize == 4 then
        return self:gBits32()
    else
        return self:gBits64()
    end
end

function Reader:gSizet()
    if self.sizetSize == 4 then
        return self:gBits32()
    else
        return self:gBits64()
    end
end

function Reader:gInteger()
    if self.integerSize == 4 then
        return self:gBits32()
    else
        return self:gBits64()
    end
end

function Reader:gNumber()
    -- Double precision float (8 bytes IEEE 754)
    local b1 = self:gByte()
    local b2 = self:gByte()
    local b3 = self:gByte()
    local b4 = self:gByte()
    local b5 = self:gByte()
    local b6 = self:gByte()
    local b7 = self:gByte()
    local b8 = self:gByte()
    
    if self.bigEndian then
        b1, b2, b3, b4, b5, b6, b7, b8 = b8, b7, b6, b5, b4, b3, b2, b1
    end
    
    local sign = (b8 >= 128) and -1 or 1
    local exponent = (b8 % 128) * 16 + math.floor(b7 / 16)
    
    local mantissa = (exponent == 0) and 0.0 or 1.0
    local scale = 0.5
    local b7_fraction = b7 % 16
    
    for i = 3, 0, -1 do
        local bit = math.floor(b7_fraction / (2^i)) % 2
        if bit == 1 then mantissa = mantissa + scale end
        scale = scale * 0.5
    end
    
    local bytes = {b6, b5, b4, b3, b2, b1}
    for j = 1, 6 do
        local byte_val = bytes[j]
        for i = 7, 0, -1 do
            local bit = math.floor(byte_val / (2^i)) % 2
            if bit == 1 then mantissa = mantissa + scale end
            scale = scale * 0.5
        end
    end
    
    if exponent == 0 then
        if mantissa == 0 then
            if sign < 0 then
                return -1 / math.huge
            end
            return 0.0
        end
        return sign * mantissa * (2 ^ -1022)
    elseif exponent == 2047 then
        if mantissa == 1.0 then
            return sign * math.huge
        end
        return 0 / 0
    end

    return sign * mantissa * (2 ^ (exponent - 1023))
end

function Reader:gString51()
    local size = self:gSizet()
    if size == 0 then
        return ""
    end
    local val = self:read(size)
    return string.sub(val, 1, #val - 1) -- Remove null terminator
end

function Reader:gString53()
    local size = self:gBits8()
    if size == 0 then
        return nil
    end
    if size == 0xFF then
        size = self:gSizet()
    end
    local actualLen = size - 1
    if actualLen <= 0 then
        return ""
    end
    return self:read(actualLen)
end

return Reader
