local command_line_args = rawget(_G, "arg")
local game_guardian = rawget(_G, "gg")
local entry_name = ...

local MODULES_USED_BY_COMPILER = {
    "src.parser.parser", "src.parser.reader", "src.generator.generator",
    "src.generator.opcodes", "src.obfuscator.init",
    "src.obfuscator.control_flow", "src.obfuscator.string_extract",
    "src.obfuscator.op_scramble", "src.obfuscator.constants",
    "src.obfuscator.super_ops", "src.obfuscator.tamper",
    "src.minifier.minifier", "src.utils.helpers"
}

if game_guardian then
    for index = 1, #MODULES_USED_BY_COMPILER do
        package.loaded[MODULES_USED_BY_COMPILER[index]] = nil
    end
end

local parser = require("src.parser.parser")
local generator = require("src.generator.generator")

local DEFAULT_SETTINGS = {
    debug = false,
    anti_tamper = true,
    encrypt_constants = true,
    super_operators = true,
    minify = true,
    dump_binary = true
}

local function copy_settings(settings)
    settings = settings or {}

    local result = {}
    for name, default_value in pairs(DEFAULT_SETTINGS) do
        local value = settings[name]
        if value == nil then value = default_value end
        result[name] = not not value
    end

    if result.debug then result.anti_tamper = false end

    return result
end

local function read_file(path)
    local handle, open_error = io.open(path, "rb")
    if not handle then return nil, open_error end

    local success, content = pcall(handle.read, handle, "*a")
    handle:close()

    if not success then return nil, content end
    return content
end

local function write_file(path, content)
    local handle, open_error = io.open(path, "wb")
    if not handle then return nil, open_error end

    local success, write_error = pcall(handle.write, handle, content)
    handle:close()

    if not success then return nil, write_error end
    return true
end

local function basename(path)
    return tostring(path):match("([^/\\]+)$") or tostring(path)
end

local function dirname(path)
    return tostring(path):match("^(.*)[/\\][^/\\]+$") or "."
end

local function join_path(directory, filename)
    if directory:match("[/\\]$") then return directory .. filename end
    return directory .. "/" .. filename
end

local function output_filename(input_path)
    local filename = basename(input_path)
    if filename:match("%.[Ll][Uu][Aa]$") then
        return filename:gsub("%.[Ll][Uu][Aa]$", "_enc.lua")
    end
    return filename .. "_enc.lua"
end

local Compiler = {}
Compiler.__index = Compiler

function Compiler.new(options)
    options = options or {}

    local instance = {
        parser = options.parser or parser,
        generator = options.generator or generator,
        game_guardian = options.game_guardian
    }
    return setmetatable(instance, Compiler)
end

function Compiler:_dump_function(func, strip_debug)
    return string.dump(func, strip_debug and true or false)
end

function Compiler:_compile_natively(source, source_name)
    local loader = loadstring or load
    local func, syntax_error = loader(source, "@" .. source_name)
    if not func then
        error("Syntax error in " .. source_name .. ": " ..
                  tostring(syntax_error), 0)
    end
    return self:_dump_function(func, true)
end

function Compiler:_compile_with_game_guardian(source)
    local gg_api = self.game_guardian
    if not gg_api or not gg_api.internal2 then return nil end

    local scratch_path = "LuaObfVM.tmp.lua"
    local internal_output_path = os.tmpname()

    local success, result = pcall(function()
        local written, write_error = write_file(scratch_path, source)
        assert(written, write_error)

        local source_func, load_error = loadfile(scratch_path)
        assert(source_func, load_error)
        local initial_bytecode = self:_dump_function(source_func, true)

        written, write_error = write_file(scratch_path, initial_bytecode)
        assert(written, write_error)

        local bytecode_func, bytecode_error = loadfile(scratch_path)
        assert(bytecode_func, bytecode_error)
        gg_api.internal2(bytecode_func, internal_output_path)

        local internal_bytecode, read_error = read_file(internal_output_path)
        assert(internal_bytecode, read_error)

        written, write_error = write_file(scratch_path, internal_bytecode)
        assert(written, write_error)

        local final_func, final_error = loadfile(scratch_path)
        assert(final_func, final_error)
        return self:_dump_function(final_func, true)
    end)

    os.remove(scratch_path)
    os.remove(internal_output_path)

    if success then return result end
    return nil, result
end

function Compiler:_source_to_bytecode(source, source_name)
    if source:sub(1, 4) == "\27Lua" then return source end

    local bytecode = self:_compile_with_game_guardian(source)
    if bytecode then return bytecode end

    return self:_compile_natively(source, source_name)
end

function Compiler:compile_file(input_path, output_path, settings)
    assert(type(input_path) == "string" and input_path ~= "",
           "Input path is required")
    assert(type(output_path) == "string" and output_path ~= "",
           "Output path is required")

    local source, read_error = read_file(input_path)
    if not source then
        error("Cannot read input file " .. input_path .. ": " ..
                  tostring(read_error), 0)
    end

    local options = copy_settings(settings)
    local bytecode = self:_source_to_bytecode(source, input_path)
    local tree = self.parser.decode_bytecode(bytecode)
    local output = self.generator.generate_code(tree, options)

    if options.dump_binary then
        local loader = loadstring or load
        local func, syntax_error = loader(output, "@" .. input_path)
        if not func then
            error("Generated code is invalid: " .. tostring(syntax_error), 0)
        end
        output = self:_dump_function(func, true)
    end

    local written, write_error = write_file(output_path, output)
    if not written then
        error("Cannot write output file " .. output_path .. ": " ..
                  tostring(write_error), 0)
    end

    return true
end

local Application = {}
Application.__index = Application

function Application.new(compiler, gg_api)
    return setmetatable({
        compiler = assert(compiler, "Compiler instance is required"),
        game_guardian = gg_api
    }, Application)
end

function Application:_print_usage()
    print("Usage: lua compiler.lua <input.lua> <output.lua> [options]")
    print("Options:")
    print(
        "  --debug                Keep debug information and disable anti-tamper")
    print("  --no-anti-tamper       Disable anti-tamper and line checks")
    print("  --no-super-operators   Disable super-operator grouping")
    print("  --no-encrypt-consts    Disable XOR constant encryption")
    print("  --no-minify            Disable source minification")
    print(
        "  --no-dump-binary       Write generated Lua source instead of bytecode")
end

function Application:_parse_cli_settings(args)
    local settings = copy_settings()
    local disabled_options = {
        ["--no-anti-tamper"] = "anti_tamper",
        ["--no-super-operators"] = "super_operators",
        ["--no-encrypt-consts"] = "encrypt_constants",
        ["--no-minify"] = "minify",
        ["--no-dump-binary"] = "dump_binary"
    }

    for index = 3, #args do
        local option = args[index]
        local setting_name = disabled_options[option]
        if option == "--debug" then
            settings.debug = true
            settings.anti_tamper = false
        elseif setting_name then
            settings[setting_name] = false
        else
            error("Unknown option: " .. tostring(option), 0)
        end
    end

    return settings
end

function Application:run_cli(args)
    if not args then
        print(
            "LuaObfVM loaded. Use compile('input.lua', 'output.lua') to compile a file.")
        return true
    end

    local input_path = args[1]
    local output_path = args[2]
    if not input_path or not output_path then
        self:_print_usage()
        return false
    end

    local settings = self:_parse_cli_settings(args)
    self.compiler:compile_file(input_path, output_path, settings)
    print("Compiled " .. input_path .. " -> " .. output_path)
    return true
end

function Application:_load_game_guardian_config(config_path, defaults)
    local config_chunk = loadfile(config_path)
    if not config_chunk then return defaults end

    local success, config = pcall(config_chunk)
    if success and type(config) == "table" then return config end
    return defaults
end

function Application:run_game_guardian()
    local gg_api = self.game_guardian
    local current_file = gg_api.getFile()
    local config_path = gg_api.EXT_CACHE_DIR .. "/" .. basename(current_file) ..
                            "cfg"
    local defaults = {
        current_file, dirname(current_file), false, true, true, true, true, true
    }
    local saved_values = self:_load_game_guardian_config(config_path, defaults)

    local inputs = gg_api.prompt({
        "Input Lua script:", "Output directory:",
        "Debug mode (disables anti-tamper):",
        "Enable anti-tamper and line checks:", "Encrypt constants with XOR:",
        "Enable super operators:", "Minify generated source:",
        "Write binary bytecode:"
    }, saved_values, {
        "file", "path", "checkbox", "checkbox", "checkbox", "checkbox",
        "checkbox", "checkbox"
    })

    if not inputs then
        gg_api.toast("Compilation cancelled.")
        return false
    end

    gg_api.saveVariable(inputs, config_path)

    local input_path = inputs[1]
    local output_path = join_path(inputs[2], output_filename(input_path))
    local settings = {
        debug = inputs[3],
        anti_tamper = inputs[4],
        encrypt_constants = inputs[5],
        super_operators = inputs[6],
        minify = inputs[7],
        dump_binary = inputs[8]
    }

    local success, compile_error = pcall(self.compiler.compile_file,
                                         self.compiler, input_path, output_path,
                                         settings)

    if success then
        gg_api.alert("Compilation completed.\n\nOutput: " .. output_path)
        return true
    end

    gg_api.alert("Compilation failed.\n\n" .. tostring(compile_error))
    return false
end

function Application:run(args)
    if self.game_guardian then return self:run_game_guardian() end
    return self:run_cli(args)
end

local default_compiler = Compiler.new({game_guardian = game_guardian})

local function compile(input_path, output_path, settings)
    local result = default_compiler:compile_file(input_path, output_path,
                                                 settings)
    print("Compiled " .. input_path .. " -> " .. output_path)
    return result
end

_G.compile = compile

local application = Application.new(default_compiler, game_guardian)
local module = {
    Compiler = Compiler,
    Application = Application,
    compile = compile,
    defaults = copy_settings
}

local loaded_as_module = entry_name == "compiler"
if not loaded_as_module then
    local success, result = pcall(application.run, application,
                                  command_line_args)
    if not success then
        local message = "Error: " .. tostring(result) .. "\n"
        if io.stderr then
            io.stderr:write(message)
        else
            print(message)
        end
        if not game_guardian and os.exit then os.exit(1) end
    elseif result == false and not game_guardian and os.exit then
        os.exit(1)
    end
end

return module
