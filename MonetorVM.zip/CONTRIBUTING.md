# Contributing to LuaObfVM

Contributions that improve correctness, compatibility, performance, or documentation are welcome.

## Before submitting a change

1. Keep changes focused and avoid unrelated formatting rewrites.
2. Preserve compatibility with Lua 5.1, Lua 5.2, and Lua 5.3.
3. Test both the original script and generated output with the same runtime.
4. Test with default settings and with relevant protection features disabled.
5. Do not remove copyright, license, or attribution notices. Generated output branding is maintained by Monetor.

## Reporting bugs

Include the following information in a bug report:

- Lua version and execution environment
- Compiler options
- Minimal source script that reproduces the issue
- Expected behavior and actual behavior
- Complete error output, if available

Do not submit private scripts, credentials, or other sensitive information.

## Pull requests

A pull request should explain the problem, describe the solution, and list the tests performed. New opcode or parser behavior should include a minimal regression case covering the affected Lua versions.

By submitting a contribution, you agree that it may be distributed under the Apache License, Version 2.0.
