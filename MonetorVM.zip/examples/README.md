# Examples

- `input.lua` is a small example input.
- Run the compiler to generate an output file; generated output files are not checked into this Monetor-branded repository.

From the repository root, for example:

```sh
lua5.3 compiler.lua examples/input.lua examples/output.lua --no-dump-binary --no-minify
```

Use a Lua runtime version compatible with the input bytecode and the target environment.
