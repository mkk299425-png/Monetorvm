-- Example Lua script to demonstrate LuaObfVM obfuscation

local function greet(name)
    local message = "Hello, " .. tostring(name) .. "!"
    print(message)
    return message
end

local sum = 0
for i = 1, 10 do
    sum = sum + i
end

greet("World")
print("Sum of 1 to 10 is: " .. tostring(sum))
