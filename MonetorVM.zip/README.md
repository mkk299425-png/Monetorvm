# Monetor LuaObfVM

LuaObfVM is an offline Lua bytecode obfuscator built around a custom virtual machine. It can be used from a desktop command line or from GameGuardian without requiring an online service.

## Features

- Custom virtual-machine execution layer
- Opcode scrambling and optional super operators
- XOR-protected constants
- Optional anti-tamper and line-integrity checks
- Source minification and binary bytecode output
- Desktop and GameGuardian workflows
- Lua 5.1, Lua 5.2, and Lua 5.3 bytecode support

## Obfuscation pipeline

```mermaid
flowchart LR
    A["Lua source"] --> B["Lua bytecode compilation"]
    B --> C["Bytecode parser"]
    C --> D["Instructions, constants, and prototypes"]
    D --> E["Constant protection"]
    D --> F["Opcode scrambling"]
    D --> G["Super-operator generation"]
    E --> H["Custom VM generation"]
    F --> H
    G --> H
    H --> I["Optional anti-tamper checks"]
    I --> J["Source minification"]
    J --> K["Protected Lua source or binary bytecode"]
    K --> L["Desktop Lua or LuaGG"]
```

The compiler reads the bytecode produced from the input script, separates its instructions, constants, and nested prototypes, then applies the enabled transformations. It generates a custom interpreter for the transformed program and optionally adds anti-tamper checks, minification, and binary output.

## Requirements

- Lua 5.1, 5.2, or 5.3
- A filesystem layout that preserves the `src` directory next to `compiler.lua`

Lua 5.4 and Lua 5.5 bytecode are not currently supported.

## Command-line usage

```sh
lua5.3 compiler.lua input.lua output.lua
```

The compiler enables all protection features by default. Available options:

```text
--debug                Keep debug information and disable anti-tamper checks
--no-anti-tamper       Disable anti-tamper and line checks
--no-super-operators   Disable super-operator grouping
--no-encrypt-consts    Disable XOR constant encryption
--no-minify            Disable source minification
--no-dump-binary       Write generated Lua source instead of binary bytecode
```

Examples:

```sh
lua5.1 compiler.lua input.lua output.lua
lua5.2 compiler.lua input.lua output.lua --no-dump-binary --no-minify
lua5.3 compiler.lua input.lua output.lua --debug
```

The generated file must be executed by a compatible Lua runtime.

## Examples

A complete input/output example is provided in the [examples/](examples) directory:
- Original source: [input.lua](examples/input.lua)
- Obfuscated Lua source: [output_source.lua](examples/output_source.lua)
- Obfuscated binary bytecode: [output_binary.lua](examples/output_binary.lua)

For more information, see the [examples/README.md](examples/README.md).


## GameGuardian usage

1. Copy the repository while preserving its directory structure.
2. Run `compiler.lua` from GameGuardian.
3. Select the input script and output directory.
4. Choose the required compiler options in the prompt.

GameGuardian-specific checks are not embedded into protected output, allowing the same generated VM design to remain portable across desktop Lua and LuaGG environments.

## Project structure

```text
compiler.lua              Command-line and GameGuardian entry point
src/parser/               Lua bytecode readers and decoders
src/generator/            VM and opcode code generation
src/obfuscator/           Constant, control-flow, and opcode transforms
src/minifier/             Lua source minification and name obfuscation
src/utils/                Shared helper functions
```

## Compatibility and testing

The project has been differential-tested on Lua 5.1.5, Lua 5.2.4, and Lua 5.3.6. Coverage includes closures, upvalues, varargs, binary strings, Lua patterns, coroutines, metatables, large constant tables, large control-flow chunks, special floating-point values, and version-specific syntax.

The uncommon Lua 5.1 pattern `getfenv(2)` or deeper is not fully virtualized because the custom VM has a different native call stack. `getfenv(1)`, `setfenv(1, env)`, and function-based environment changes are supported.

## Security notice

Obfuscation increases the effort required to inspect or modify a script, but it is not cryptographic protection and cannot guarantee that client-side code is impossible to recover. Do not place secrets in distributed scripts.

## Attribution

This repository is maintained and branded by Monetor.

If you use, redistribute, or fork this project, retain the copyright and attribution notices in `LICENSE` and `NOTICE`, and credit OnlyTris as the original author. Distributed derivative works must preserve the notices required by the Apache License 2.0.

## License

Licensed under the Apache License, Version 2.0. See `LICENSE` and `NOTICE` for details.
